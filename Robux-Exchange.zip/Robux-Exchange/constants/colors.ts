const Colors = {
  primary: "#0066FF",
  primaryDark: "#0052CC",
  background: "#E0E0E0",
  cardBackground: "#FFFFFF",
  headerBackground: "#393B3D",
  text: "#191919",
  textSecondary: "#606162",
  textMuted: "#999",
  white: "#FFFFFF",
  black: "#000000",
  border: "#E0E0E0",
  success: "#00B06F",
  danger: "#FF4444",
  robuxGold: "#FFD700",
  strikethrough: "#999",
  freeGreen: "#0066FF",
  overlay: "rgba(0,0,0,0.5)",
  light: {
    text: "#191919",
    background: "#E0E0E0",
    tint: "#0066FF",
    tabIconDefault: "#ccc",
    tabIconSelected: "#0066FF",
  },
};

export default Colors;
