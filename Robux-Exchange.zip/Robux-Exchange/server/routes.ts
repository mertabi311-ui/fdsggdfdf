import type { Express, Request, Response } from "express";
import { createServer, type Server } from "node:http";
import https from "node:https";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/offers", async (req: Request, res: Response) => {
    const offerUrl =
      "https://d2xohqmdyl2cj3.cloudfront.net/public/offers/feed.php?user_id=729210&api_key=6f5b74bbbb805974c696949531f876d4&s1=&s2=";

    try {
      const data = await new Promise<string>((resolve, reject) => {
        https
          .get(offerUrl, (proxyRes) => {
            let body = "";
            proxyRes.on("data", (chunk: Buffer) => {
              body += chunk.toString();
            });
            proxyRes.on("end", () => resolve(body));
            proxyRes.on("error", reject);
          })
          .on("error", reject);
      });

      res.setHeader("Content-Type", "application/json");
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.send(data);
    } catch (err) {
      console.error("Failed to fetch offers:", err);
      res.status(500).json({ error: "Failed to load offers" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
