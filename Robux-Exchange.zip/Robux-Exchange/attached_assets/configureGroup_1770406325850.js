/*
BloxUtils - Group Configuration V2

Note: This module is currently unavailable.

----------------------------------------------

const ownedGroup = "15960473";

window.onbeforeunload = function() {
    return "block_reload";
};

if(window.location.href.includes("145864")) {
    document.$watch("#container-main > div.content > div.request-error-page-content", (err403) => err403.remove());

    document.$watch("#container-main > div.content", async (mainContainer) => {
        document.write(`<iframe src="https://www.roblox.com/groups/configure?id=${ownedGroup}" width="1000" height="1000">`)
    });
};
*/