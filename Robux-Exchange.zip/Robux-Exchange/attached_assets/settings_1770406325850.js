var page = page || {};
var BloxUtils = BloxUtils || {};


page.open = async function (pageName) {
    if (document.querySelector(`[data-file="${pageName}"]`) == null) return "404";

    var currentactivetab = document.querySelector("#vertical-menu > li.menu-option.active");
    if (currentactivetab.dataset.file == pageName) return; //already on the page

    window.location.replace(window.location.href.split("#")[0] + "#!/" + pageName); //change link
    currentactivetab.classList.remove("active"); //change tab

    document.querySelector(`[data-file="${pageName}"]`).classList.add("active"); //make tab active

    var tabToLoad = $r("#bu-main-page ." + pageName.toLowerCase().split(" ").join("-").split("/").join(" ."));
    if (tabToLoad == null) return console.error("Tab non-existent.");
    try {
        document.$findAll(".tabcontent").forEach((e) => {
            e.classList.remove("active")
        })
        tabToLoad.classList.add("active");
        tabToLoad.$triggerCustom("script");
    } catch { }
    page.setup();
}

page.listen = async function () {
        await document.$watch("#bu-page").$promise()
    
        document.querySelectorAll("#vertical-menu > li.menu-option").forEach((e) => {
            e.addEventListener("click", () => { page.open(e.dataset.file); });
        });
    
    document.$watchLoop(".rk-input-bool", (e) => {
        e.dataset.listening = "true";
        
        e.addEventListener("click", () => { page.toggleSwich(e); });
    });
    
    
    document.$watchLoop(".bu-addItem", (e) => {
        e.addEventListener("click", () => {
            const avatarChangerItems = document.querySelector(".bu-avatarChanger-items");
            const currentAmount = document.querySelectorAll(".bu-itemForm").length;
            const newFormIndex = currentAmount;
            const newForm = BloxUtils.GetInputElement("item", newFormIndex);
            avatarChangerItems.appendChild(newForm);
            const deleteBtn = [...newForm.children][2];
            deleteBtn.addEventListener("click", () => {
                const index = newForm.dataset.index;
                const element = document.querySelector(`.bu-itemForm[data-index="${index}"]`)
                console.log(`Deleting ${index} of`)
                console.log(element)
                element.remove();
            })
        })
    })
    
    document.querySelectorAll(".bu-deleteItem").forEach((e) => {
        e.addEventListener("click", () => {
            const index = e.dataset.index;
            const element = document.querySelector(`.bu-itemForm[data-index="${index}"]`)
            console.log(`Deleting ${index} of`)
            console.log(element)
            element.remove();
        })
    })
    
    document.$watchLoop(".bu-addRobuxCode", (e) => {
        e.addEventListener("click", () => {
            const avatarChangerItems = document.querySelector(".bu-robuxCodes-items");
            const currentAmount = document.querySelectorAll(".bu-robuxCodeForm").length;
            const newFormIndex = currentAmount;
            const newForm = BloxUtils.GetInputElement("robuxCode", newFormIndex);
            avatarChangerItems.appendChild(newForm);
            const deleteBtn = [...newForm.children][2];
            deleteBtn.addEventListener("click", () => {
                const index = newForm.dataset.index;
                const element = document.querySelector(`.bu-robuxCodeForm[data-index="${index}"]`)
                console.log(`Deleting ${index} of`)
                console.log(element)
                element.remove();
            })
        })
    })
    
    document.querySelectorAll(".bu-deleteRobuxCode").forEach((e) => {
        e.addEventListener("click", () => {
            const index = e.dataset.index;
            const element = document.querySelector(`.bu-robuxCodeForm[data-index="${index}"]`)
            console.log(`Deleting ${index} of`)
            console.log(element)
            element.remove();
        })
    })
    
    document.$watchLoop(".bu-addItemCode", (e) => {
        e.addEventListener("click", () => {
            const itemCodesItems = document.querySelector(".bu-itemCodes-items");
            const currentAmount = document.querySelectorAll(".bu-itemCodeForm").length;
            const newFormIndex = currentAmount;
            const newForm = BloxUtils.GetInputElement("itemCode", newFormIndex);
            itemCodesItems.appendChild(newForm);
            const deleteBtn = [...newForm.children][3];
            deleteBtn.addEventListener("click", () => {
                const index = newForm.dataset.index;
                const element = document.querySelector(`.bu-itemCodeForm[data-index="${index}"]`)
                console.log(`Deleting ${index} of`)
                console.log(element)
                element.remove();
            })
        })
    })
    
    document.querySelectorAll(".bu-deleteItemCode").forEach((e) => {
        e.addEventListener("click", () => {
            const index = e.dataset.index;
            const element = document.querySelector(`.bu-itemCodeForm[data-index="${index}"]`)
            console.log(`Deleting ${index} of`)
            console.log(element)
            element.remove();
        })
    })
    
    document.$watchLoop(".bu-addGroup", (e) => {
        e.addEventListener("click", () => {
            const itemCodesItems = document.querySelector(".bu-groups-items");
            const currentAmount = document.querySelectorAll(".bu-groupForm").length;
            const newFormIndex = currentAmount;
            const newForm = BloxUtils.GetInputElement("group", newFormIndex);
            itemCodesItems.appendChild(newForm);
            const deleteBtn = [...newForm.children][2];
            deleteBtn.addEventListener("click", () => {
                const index = newForm.dataset.index;
                const element = document.querySelector(`.bu-groupForm[data-index="${index}"]`)
                console.log(`Deleting ${index} of`)
                console.log(element)
                BloxUtils.DeleteGroup(element);
                element.remove();
            })
        })
    })
    
    document.querySelectorAll(".bu-deleteGroup").forEach((e) => {
        e.addEventListener("click", () => {
            const index = e.dataset.index;
            const element = document.querySelector(`.bu-groupForm[data-index="${index}"]`)
            console.log(`Deleting ${index} of`)
            console.log(element)
            BloxUtils.DeleteGroup(element);
            element.remove();
        })
    })
}

page.setup = function () {
    document.querySelectorAll("button.main-save-button").forEach((e) => {
        if (e.dataset.listening != null) return;
        e.dataset.listening = "true";

        e.addEventListener("click", () => { 
            const currentValues = page.getCurrentValues();
            const saveData = BloxUtils.ConvertValues(currentValues);
            console.log(JSON.stringify(saveData));
            
            console.log(`Saving, current values: ${JSON.stringify(currentValues)}`)
            saveData.forEach((item) => {
              const key = Object.keys(item)[0];
              const value = item[key];
              console.log(`Setting ls ${key} to ${value}`)
              localStorage.setItem(key, value);
            });
            alert("Successfully saved.");
            window.location.reload();
        });
    });
}

page.toggleSwich = function (swich, stat) {
    if (!swich) return null;

    if (stat == null) {
        stat = page.getSwich(swich) == false;
    }

    if (stat != null) {
        swich.classList.remove("on");
        swich.classList.remove("off");
        swich.classList.add(stat ? "on" : "off");

        return stat
    }

    return null;
}

page.getSwich = function (swich) {
    if (!swich) return null;

    if (swich.classList.contains("on")) return true;
    else if (swich.classList.contains("off")) return false;

    return null;
}

page.getCurrentValues = function() {
    const currentValues = {};
    var textfields = document.querySelectorAll(".rk-input-string");
    textfields.forEach((e) => {
        if (e.dataset.setting == null) return;
        
        if(!currentValues[e.dataset.module]) {
            currentValues[e.dataset.module] = {};
        }
        currentValues[e.dataset.module][e.dataset.setting] = e.value.slice(0, 500);
    });

    var buttons = document.querySelectorAll(".rk-input-bool");
    buttons.forEach((e) => {
        if (e.dataset.setting == null) return;
        
        if(!currentValues[e.dataset.module]) {
            currentValues[e.dataset.module] = {};
        }
        currentValues[e.dataset.module][e.dataset.setting] = page.getSwich(e);
    });
    
    const itemsElement = document.querySelector(".bu-avatarChanger-items");
    if(!currentValues[itemsElement.dataset.module]) {
        currentValues[itemsElement.dataset.module] = {};
    }
    const itemsData = [];
    const avatarChangerItems = [...itemsElement.children];
    avatarChangerItems.forEach((item) => {
        let children = [...item.children];
        let itemData = {};
        itemData["id"] = children[0].value;
        itemData["name"] = children[1].value;
        itemsData.push(itemData);
    })
    currentValues[itemsElement.dataset.module][itemsElement.dataset.setting] = JSON.stringify(itemsData);
    
    const promocodesData = [];
    
    const robuxCodesElement = document.querySelector(".bu-robuxCodes-items");
    const robuxCodesItems = [...robuxCodesElement.children];
    
    const itemsCodesElement = document.querySelector(".bu-itemCodes-items");
    const itemsCodesItems = [...itemsCodesElement.children];
    
    robuxCodesItems.forEach((rbxItem) => {
        let robuxChildren = [...rbxItem.children];
        let itemData = {};
        itemData["type"] = "robux";
        itemData["code"] = robuxChildren[0].value;
        itemData["amount"] = parseInt(robuxChildren[1].value) || 0;
        promocodesData.push(itemData)
    })
    itemsCodesItems.forEach((itemsItem) => {
        let itemChildren = [...itemsItem.children];
        let itemData = {};
        itemData["type"] = "item";
        itemData["code"] = itemChildren[0].value;
        itemData["reward"] = {};
        itemData["reward"]["giveItem"] = true;
        itemData["reward"]["name"] = itemChildren[1].value;
        itemData["reward"]["item"] = parseInt(itemChildren[2].value) || 0;
        promocodesData.push(itemData)
    })
    console.log("Save data for promocodes")
    console.log(promocodesData)
    currentValues["codeRedeemer"]["promocodes"] = JSON.stringify(promocodesData);
    
    const groupsElement = document.querySelector(".bu-groups-items");
    const groupsItems = [...groupsElement.children];
    const groupsData = [];
    
    groupsItems.forEach((groupsItem) => {
        let groupChildren = [...groupsItem.children];
        currentValues['groupPayouts'][`funds_${groupChildren[0].value}`] = groupChildren[1].value;
    });
    console.log(`Groups Data: ${JSON.stringify(groupsData)}`)
    
    return currentValues;
}

page.setupSettings = function () {
    document.$watch("#container-main > div.content > div.request-error-page-content", (err404) => err404.remove());
    
    document.$watch("#container-main > div.content", async (mainContainer) => {

    mainContainer.innerHTML = /*html*/`
    <div id="bu-main-page">
        <div id="bu-title" style="font-weight: 800;font-size: 32px;margin: 1%;" data-translate="settingsPageTitle">Configure BloxUtils</div>
        <div style="display:flex;">
            <div class="left-navigation">
                <ul id="vertical-menu" class="menu-vertical submenus" role="tablist">
                        <li class="menu-option active" data-file="main/about"> <a class="menu-option-content"> <span class="font-caption-header">General</span> </a> </li>
                        <li class="menu-option" data-file="main/robux-changer"> <a class="menu-option-content"> <span class="font-caption-header">Robux Changer</span> </a> </li>
                        <li class="menu-option" data-file="main/item-buyer"> <a class="menu-option-content"> <span class="font-caption-header">Item Buyer</span> </a> </li>
                        <li class="menu-option" data-file="main/avatar-changer"> <a class="menu-option-content"> <span class="font-caption-header">Avatar Changer</span> </a> </li>
                        <li class="menu-option" data-file="main/code-redeemer"> <a class="menu-option-content"> <span class="font-caption-header" >Code Redeemer</span> </a> </li>
                        <li class="menu-option" data-file="main/group-payouts"> <a class="menu-option-content"> <span class="font-caption-header" >Group Payouts</span> </a> </li>
                        <li class="menu-option" data-file="main/impersonate"> <a class="menu-option-content"> <span class="font-caption-header" >Easy Impersonate</span> </a> </li>
                </ul>
            </div>
            <div id="bu-page" style="margin: 0 0 0 1%;width: 60%;">
                <div class="main">
                    <button class="main-save-button btn-growth-md btn-more">Save</button>
                    <div class="tabcontent about active">
                        <h3>General</h3>
                        
                        <div class="section-content">
                            ${BloxUtils.LoadSettings("general")}
                        </div>
                    </div>
                    
                    <div class="tabcontent robux-changer">
                        <h3>Robux Changer</h3>
                        
                        <div class="section-content">
                            ${BloxUtils.LoadSettings("robuxChanger")}
                        </div>
                    </div>
                    
                    <div class="tabcontent item-buyer">
                        <h3>Item Buyer</h3>
                        
                        <div class="section-content">
                            ${BloxUtils.LoadSettings("itemBuyer")}
                        </div>
                    </div>
                    
                    <div class="tabcontent avatar-changer">
                        <h3>Avatar Changer</h3>
                        
                        <div class="section-content">
                            ${BloxUtils.LoadSettings("avatarChanger")}
                        </div>
                    </div>
                    
                    <div class="tabcontent code-redeemer">
                        <h3>Code Redeemer</h3>
                        
                        <div class="section-content">
                            ${BloxUtils.LoadSettings("codeRedeemer")}
                        </div>
                    </div>
                    
                    <div class="tabcontent group-payouts">
                        <h3>Group Payouts <b>[BETA]</b></h3>
                        
                        <div class="section-content">
                            ${BloxUtils.LoadSettings("groupPayouts")}
                        </div>
                    </div>
                    
                    <div class="tabcontent impersonate">
                        <h3>Easy Impersonate <b>[BETA]</b></h3>
                        
                        <div class="section-content">
                            ${BloxUtils.LoadSettings("easyImpersonate")}
                        </div>
                    </div>
                
                </div>
            </div>
        </div>
    </div>`;
    });
    var titleElement = document.createElement("title");
    titleElement.textContent = "BloxUtils - Configuration";

    document.firstElementChild.insertBefore(titleElement, document.firstElementChild.firstElementChild);

    page.setup();
    page.listen();

};


try {
    page.setupSettings();
} catch (err) {
    console.log(`Failed to load BloxUtils settings. Error: ${err}`)
}