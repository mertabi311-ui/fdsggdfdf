$r = (() => {
    let $ = {};
    
    /*assigning multiple functions*/
    function Assign(stuff, data) { stuff.forEach(constructor => { Object.assign(constructor.prototype, data); }) }
    
    if (self.document) {
        $ = function(selector) { return $.find(document, selector); } /* $(selector) == $.find(document, selector)*/
        $.all = function(selector) { return $.findAll(document, selector); }; /* $.all(selector) == $.findall(document, selector)*/
        
        const Observers = new WeakMap();

        function addWatch(target, selector, filter, resolve) {
            const item = {
                checked: new WeakSet(),
                firstSearch: false,
                stopped: false,

                resolve(node) {
                    this.stopped = true;
                    resolve(node);
                },

                execute() {
                    if (!this.firstSearch) {
                        const elem = target.$find(selector);
                        if (!elem) return;

                        this.firstSearch = true;
                        this.checked.add(elem);

                        if (!filter || filter(elem)) {
                            item.resolve(elem);
                            if (item.stopped) return;
                        }
                    }

                    const matches = target.$findAll(selector);

                    for (let index = 0; index < matches.length; index++) {
                        const match = matches[index];

                        if (!this.checked.has(match)) {
                            this.checked.add(match);

                            if (!filter || filter(match)) {
                                this.resolve(match);
                                if (this.stopped) return;
                            }
                        }
                    }
                }
            };

            item.execute();

            if (!item.stopped) {
                let observer = Observers.get(target);

                if (!observer) {
                    observer = new MutationObserver(handleMuts);
                    Observers.set(target, observer);

                    observer.listeners = [];
                    observer.target = target;

                    observer.observe(target, { childList: true, subtree: true });
                }

                observer.listeners.push(item);
            }
        }

        const watchProto = {
            $watch(...args) {
                const finishPromise = this.targetPromise.then(target => target.$watch(...args).finishPromise);
    
                return {
                    targetPromise: this.targetPromise,
                    finishPromise,
    
                    parent: this.parent,
                    __proto__: watchProto
                }
            },
            
            $watchLoop(...args) {
                this.targetPromise.then(target => { target.$watchLoop(...args); });
                return this;
            },
            
            $watchData(...args) {
                this.targetPromise.then(target => { target.$watchData(...args); });
                return this;
            },
    
            $then(callback) {
                const nxt = {
                    targetPromise: this.finishPromise || this.targetPromise,
                    finishPromise: null,
                    
                    parent: this,
                    __proto__: watchProto
                };
    
                if (callback) nxt.targetPromise.then(callback);
                return nxt;
            },
    
            $back() {
                if (!this.parent) console.error("your at the top of the watcher");
                return this.parent;
            },
    
            $promise() {
                return (this.finishPromise || this.targetPromise);
            }
        };
    
        function handleMuts(muts, self) {
            const listeners = self.listeners;
            let index = 0;
    
            while (index < listeners.length) {
                const item = listeners[index];
    
                if (!item.stopped)
                    item.execute(muts);
    
                if (item.stopped) 
                    listeners.splice(index, 1);
                else
                    index++;
            }
    
            if (!listeners.length) {
                self.disconnect();
                Observers.delete(self.target);
            }
        }
        
        Object.assign($, {
            each(list, fn) { 
                Array.prototype.forEach.call(list, fn);
            },

            ready(fn) {
                if (document.readyState != "loading")
                    fn();
                else
                    document.addEventListener("DOMContentLoaded", fn, { once: true });
            },

            watch(target, selectors, filter, callback) {
                if (typeof callback != "function") {
                    callback = filter;
                    filter = null;
                }

                if ((target instanceof Document) || (target instanceof DocumentFragment)) {
                    target = target.documentElement;
                }

                if (!Array.isArray(selectors)) selectors = [selectors];

                let finishPromise;

                /*const promises = selectors.map(selector => addWatch(target, selector, filter));*/
                const promises = selectors.map(selector => new Promise(resolve => addWatch(target, selector, filter, resolve)));

                finishPromise = Promise.all(promises).then(elems => {
                    if (callback) {
                        try { callback(...elems); }
                        catch(ex) { console.error(selectors, ex); }
                    }
    
                    return elems[0];
                });

                return {
                    targetPromise: Promise.resolve(target),
                    finishPromise,
                    __proto__: watchProto
                }
            },
            watchLoop(target, selector, filter, callback) {

                if (typeof callback != "function") {
                    callback = filter;
                    filter = null;
                }

                if ((target instanceof Document) || (target instanceof DocumentFragment)) {
                    target = target.documentElement;
                }

                const item = {
                    checked: new WeakSet(),
                    stopped: false,

                    resolve(node) {
                        if (callback) {
                            try { callback(node, () => this.stopped = true); }
                            catch(ex) { console.error(selector, ex); }
                        }
                    },

                    execute() {
                        const matches = target.$findAll(selector);

                        for (const match of matches) {
                            if (this.checked.has(match) == false) {
                                this.checked.add(match);

                                if (!filter || filter(match)) {
                                    this.resolve(match);
                                    if (this.stopped) return;
                                }
                            }
                        }
                    }
                };

                item.execute();

                if (!item.stopped) {
                    let observer = Observers.get(target);

                    if (!observer) {
                        observer = new MutationObserver(handleMuts);
                        Observers.set(target, observer);

                        observer.listeners = [];
                        observer.target = target;

                        observer.observe(target, { childList: true, subtree: true });
                    }

                    observer.listeners.push(item);
                }
            },
            watchData(target, filter, callback) {

                if (typeof callback != "function") {
                    callback = filter;
                    filter = null;
                }

                if ((target instanceof Document) || (target instanceof DocumentFragment)) {
                    target = target.documentElement;
                }

                const item = {
                    checked: new WeakSet(),
                    stopped: false,

                    resolve(node) {
                        if (callback) {
                            try { callback(node, () => this.stopped = true); }
                            catch(ex) { console.error(ex); }
                        }
                    },

                    execute() {
                        if (!filter || filter(target)) {
                            this.resolve(target);
                            if (this.stopped) return;
                        }
                    }
                };

                item.execute();

                if (!item.stopped) {
                    let observer = Observers.get(target);

                    if (!observer) {
                        observer = new MutationObserver(handleMuts);
                        Observers.set(target, observer);

                        observer.listeners = [];
                        observer.target = target;

                        observer.observe(target, { characterData: true, attributes: true, subtree: true });
                    }

                    observer.listeners.push(item);
                }
            },

            find(self, selector, callback) {
                let result = self.querySelector(selector);
                if (callback != null && result != null) return (callback(result) || result);
                return result;
            },
            findAll(self, selector, callback) {
                let result = self.querySelectorAll(selector);
                if (callback != null && result != null && result.length > 0) Array.prototype.forEach.call(result, callback);
                return result;
            },
            clear(self) {
                Array.prototype.forEach.call(self.childNodes, (node) => {
                    node.remove();
                });
                Array.prototype.forEach.call(self.children, (element) => {
                    element.remove();
                });
            },

            on(self, events, selector, callback, config) {
                if (typeof selector == "function") { [selector, callback, config] = [null, selector, callback]; }
                if (!self.$events) { Object.defineProperty(self, "$events", { value: {} }); }

                events.split(" ").forEach(eventType => {
                    eventType = eventType.trim();

                    const eventName = eventType.replace(/^([^.]+).*$/, "$1");
                    if (!eventName) return;

                    let listeners = self.$events[eventType];
                    if (!listeners) { listeners = self.$events[eventType] = []; }

                    const handler = event => {
                        if (!selector) return callback.call(self, event, self);

                        const fn = event.stopImmediatePropagation;
                        let immediateStop = false;

                        event.stopImmediatePropagation = function() {
                            immediateStop = true;
                            return fn.call(this);
                        };

                        const path = event.composedPath();
                        const maxIndex = path.indexOf(self);
                        for (let i = 0; i < maxIndex; i++) {
                            const node = path[i];

                            if (node.matches(selector)) {
                                Object.defineProperty(event, "currentTarget", { value: node, configurable: true });
                                callback.call(self, event, self);
                                delete event.currentTarget;

                                if (immediateStop) break;
                            }
                        }

                        delete event.stopImmediatePropagation;
                    };

                    const listener = {
                        selector, callback,
                        params: [eventName, handler, config]
                    };

                    listeners.push(listener);
                    self.addEventListener(...listener.params);
                });

                return self
            },
            triggerCustom(self, type, detail) {
                self.dispatchEvent(new CustomEvent(type, { detail }));
                return self;
            }
        });
        
        Assign([self.EventTarget, EventTarget], {
            $on(...args) { return $.on(this, ...args); },
            $triggerCustom(...args) { return $.triggerCustom(this, ...args); },
            $event(...args) { return $.triggerCustom(this, ...args); }
        });

        Assign([self.Element, Element, self.Document, Document, self.DocumentFragment, DocumentFragment], {
            $each(...args) { return $.each(this.children, ...args); },
            $find(...args) { return $.find(this, ...args); },
            $findAll(...args) { return $.findAll(this, ...args); },
            $clear() { return $.clear(this); },
            $watch(...args) { return $.watch(this, ...args); },
            $watchLoop(...args) { return $.watchLoop(this, ...args); },
            $watchData(...args) { return $.watchData(this, ...args); }
        });

        Assign([self.NodeList, NodeList], {
            $each(...args) { return $.each(this, ...args); }
        });
    } else {
        $ = {};
    }

    return $;
})();

//Unfinished
converter = (() => {
    let cv = {};

    cv.directions = {
        //direction: [ left, top, right, bottom ]
        "center": [ true, true, true, true ],
        "middle": [ true, true, true, true ],

        "left": [ true, null, false, null ],
        "top": [ null, true, null, false ],
        "right": [ false, null, true, null ],
        "bottom": [ null, false, null, true ]
    };

    /*assigning multiple functions*/
    function Assign(stuff, data) { stuff.forEach(constructor => { Object.assign(constructor.prototype, data); }) }

    Object.assign(cv, {
        direction(dir) {
            if(obj == null) obj = "";
            var result = [ false, false, false, false ];

            if (dir.includes("center") || dir.includes("middle")) { result = [ true, true, true, true ]; }
            if (dir.includes("left")) { cv.directions["left"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }
            if (dir.includes("top")) { cv.directions["top"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }
            if (dir.includes("right")) { cv.directions["right"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }
            if (dir.includes("bottom")) { cv.directions["bottom"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }

            return result;
        },
        fn(obj) {
            if (typeof obj == "function") return obj();
            return obj;
        },
        color(obj) {
            var formats = {
                "0": "hex",
                "1": "rgb",
                "2": "rgba"
            };
            var format = cv.fn((obj?.format || obj?.f || obj?.type || 1));
            format = (formats[format] || "rgb");

            switch (format) {
                case "hex":
                    obj.hex = cv.fn((obj?.hex || obj));
                    obj.hex = (obj.hex || "#FFFFFF");

                    if (!obj.hex.includes("#")) { obj.hex = "#" + obj.hex; }

                    return obj.hex;
                    break;
                default:
                    obj.red = cv.fn((obj?.red || obj?.r || obj[0] || "255"));
                    obj.green = cv.fn((obj?.green || obj?.g || obj[1] || "255"));
                    obj.blue = cv.fn((obj?.blue || obj?.b || obj[2] || "255"));

                    return `rgb(${obj.red}, ${obj.green}, ${obj.blue})`;
                    break;
                case "rgba":
                    obj.red = cv.fn((obj?.red || obj?.r || obj[0] || "255"));
                    obj.green = cv.fn((obj?.green || obj?.g || obj[1] || "255"));
                    obj.blue = cv.fn((obj?.blue || obj?.b || obj[2] || "255"));
                    obj.opacity = cv.fn((obj?.opacity || obj?.transparent || obj?.transparency || obj?.o || obj?.t || obj[3] || "100"));

                    obj.opacity = Number(obj.opacity.toString().split("%").join(""));
                    if (obj.opacity > 1) obj.opacity /= 100;

                    return `rgba(${obj.red}, ${obj.green}, ${obj.blue}, ${obj.opacity})`;
                    break;
            }

            return `rgb(255, 255, 255)`;
        },
        corner(obj) {
            obj = (obj || "0px");
            obj = cv.fn(obj);

            if (typeof obj == "string") { return obj; }
            else {
                obj.topleft = cv.fn((obj.topleft || obj["top-left"] || obj.top_left || obj.tl || "0px"));
                obj.topright = cv.fn((obj.topright || obj["top-right"] || obj.top_right || obj.tr || "0px"));
                obj.bottomright = cv.fn((obj.bottomright || obj["bottom-right"] || obj.bottom_right || obj.br || "0px"));
                obj.bottomleft = cv.fn((obj.bottomleft || obj["bottom-left"] || obj.bottom_left || obj.bl || "0px"));

                if (isNaN(obj.topleft)) obj.topleft += "px";
                if (isNaN(obj.topright)) obj.topright += "px";
                if (isNaN(obj.bottomright)) obj.bottomright += "px";
                if (isNaN(obj.bottomleft)) obj.bottomleft += "px";

                return `${obj.topleft} ${obj.topright} ${obj.bottomright} ${obj.bottomleft}`;
            }

            return "0px";
        },
        border(obj) {
            obj = (obj || "none");
            obj = cv.fn(obj);

            if (typeof obj == "string" && obj.split(" ").length >= 2) {
                var elements = obj.split(" ");
                return { width: elements[0], style: elements[1], color: (elements[2] || "white")};
            } else {
                var width = "";
                if (obj.width != null || obj.w != null) { width = cv.fn((obj.width || obj.w)); }
                else {
                    obj.topwidth = cv.fn((obj.topwidth || obj.topsize || obj.tw || "0px"));
                    obj.rightwidth = cv.fn((obj.rightwidth || obj.rightsize || obj.rw || "0px"));
                    obj.bottomwidth = cv.fn((obj.bottomwidth || obj.bottomsize || obj.bw || "0px"));
                    obj.leftwidth = cv.fn((obj.leftwidth || obj.leftsize || obj.lw || "0px"));

                    if (isNaN(obj.topwidth)) obj.topwidth += "px";
                    if (isNaN(obj.rightwidth)) obj.rightwidth += "px";
                    if (isNaN(obj.bottomwidth)) obj.bottomwidth += "px";
                    if (isNaN(obj.leftwidth)) obj.leftwidth += "px";

                    width = `${obj.topwidth} ${obj.rightwidth} ${obj.bottomwidth} ${obj.leftwidth}`;
                }

                var style = "";
                if (obj.style != null || obj.s != null) { style = cv.fn((obj.style || obj.s)); }
                else {
                    obj.topstyle = cv.fn((obj.topstyle || obj.topshape || obj.ts || "none"));
                    obj.rightstyle = cv.fn((obj.rightstyle || obj.rightshape || obj.rs || "none"));
                    obj.bottomstyle = cv.fn((obj.bottomstyle || obj.bottomshape || obj.bs || "none"));
                    obj.leftstyle = cv.fn((obj.leftstyle || obj.leftshape || obj.ls || "none"));

                    style = `${obj.topstyle} ${obj.rightstyle} ${obj.bottomstyle} ${obj.leftstyle}`;
                }

                var color = "";
                if (obj.color != null || obj.c != null) { color = cv.fn((obj.color || obj.c)); }
                else {
                    obj.topcolor = cv.fn((obj.topcolor || obj.tc || "white"));
                    obj.rightcolor = cv.fn((obj.rightcolor || obj.rc || "white"));
                    obj.bottomcolor = cv.fn((obj.bottomcolor || obj.bc || "white"));
                    obj.leftcolor = cv.fn((obj.leftcolor || obj.lc || "white"));

                    color = `${obj.topcolor} ${obj.rightcolor} ${obj.bottomcolor} ${obj.leftcolor}`;
                }

                return { width: width, style: style, color: color };
            }

            return { width: "0px", style: "none", color: "white" };
        },
        size(obj) {
            obj = (obj || "fit-content");
            obj = cv.fn(obj);

            if (typeof obj == "string") {
                if (obj.split(" ").length > 1) {
                    var width = obj.split(" ")[0];
                    var height = obj.split(" ")[1];
                    return { width, height };
                }
                return { width: obj, height: obj };
            } else {
                obj.width = cv.fn((obj.width || obj.wide || obj.w || obj[0] || "fit-content"));
                obj.height = cv.fn((obj.height || obj.tall || obj.h || obj[1] || "fit-content"));
                return obj;
            }
        },
        margin(obj) {
            obj = (obj || "0px");
            obj = cv.fn(obj);

            if (typeof obj != "string") {
                var top = cv.fn((obj.top || obj.t || obj[1] || "0px"));
                var right = cv.fn((obj.right || obj.r || obj[2] || "0px"));
                var bottom = cv.fn((obj.bottom || obj.b || obj[3] || "0px"));
                var left = cv.fn((obj.left || obj.l || obj[0] || "0px"));

                return `${top} ${right} ${bottom} ${left}`;
            } else {
                return (obj || "0px");
            }
        },
        position(obj) {
            obj = (obj || null);
            obj = cv.fn(obj);

            var type = cv.fn((obj?.type || "fixed"));

            if (typeof obj == "string") {
                if (obj.split(" ").length == 1) {
                    var position = cv.direction(obj);
                    position.forEach((e, i) => { position[i] = (e ? "0px" : "unset"); });

                    var left = position[0];
                    var top = position[1];
                    var right = position[2];
                    var bottom = position[3];
                    return { left, top, right, bottom };
                } else {
                    var top = "unset";
                    var left = "unset";
                    var right = "unset";
                    var bottom = "unset";

                    obj.split(" ").forEach((axis, number) => {
                        if (
                            !axis.includes("center") && 
                            !axis.includes("middle") && 
                            !axis.includes("left") && 
                            !axis.includes("right") && 
                            !axis.includes("top") && 
                            !axis.includes("bottom")
                            ) {
                            if (axis.includes("-")) {
                                if (number == 0) { right = axis.split("-").join(""); }
                                else { bottom = axis.split("-").join(""); }
                            } else {
                                if (number == 0) { left = axis; }
                                else { top = axis; }
                            }
                        } else {
                            var position = cv.direction(axis);
                            position.forEach((e, i) => { position[i] = (e ? "0px" : "unset"); });

                            if (number == 0) {
                                left = position[0];
                                right = position[2];
                            } else {
                                top = position[1];
                                bottom = position[3];
                            }
                        }
                    });

                    return { left, top, right, bottom };
                }
            } else {
                if (obj == null) obj = [];
                obj.left = cv.fn((obj?.left || obj?.l || obj[0] || "unset"));
                obj.top = cv.fn((obj?.top || obj?.t || obj[1] || "unset"));
                obj.right = cv.fn((obj?.right || obj?.r || obj[2] || "unset"));
                obj.bottom = cv.fn((obj?.bottom || obj?.b || obj[3] || "unset"));

                return obj;
            }
        },

        toInput(item, value, customInput) {
            // depending on item give the output needed for it
            // custom Itput if given
        }
    });
    
    return cv;
})();