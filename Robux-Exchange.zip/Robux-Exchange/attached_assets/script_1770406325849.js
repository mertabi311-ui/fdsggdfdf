const configBtn = document.getElementById("config");

configBtn.onclick = function() {
    window.open("https://roblox.com/bloxutils");
}