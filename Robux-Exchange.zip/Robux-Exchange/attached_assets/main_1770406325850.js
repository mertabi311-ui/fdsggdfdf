/*
    BloxUtils v1.2
    Copyright (c) EG Scripts, 2023
    Any unauthorized distribution of this material is prohibited.
*/


// Add window-$ utilities

(function () {
    $r = (() => {
        let $ = {};
        
        /*assigning multiple functions*/
        function Assign(itemsToAssign, data) { itemsToAssign.forEach(constructor => { Object.assign(constructor.prototype, data); }) }
        if (self.document) {
            $ = function(selector) { return $.find(document, selector); } /* $(selector) == $.find(document, selector)*/
            $.all = function(selector) { return $.findAll(document, selector); }; /* $.all(selector) == $.findall(document, selector)*/
            
            const Observers = new WeakMap();
    
            function addWatch(target, selector, filter, resolve) {
                const item = {
                    checked: new WeakSet(),
                    firstSearch: false,
                    stopped: false,
    
                    resolve(node) {
                        this.stopped = true;
                        resolve(node);
                    },
    
                    execute() {
                        if (!this.firstSearch) {
                            const elem = target.$find(selector);
                            if (!elem) return;
    
                            this.firstSearch = true;
                            this.checked.add(elem);
    
                            if (!filter || filter(elem)) {
                                item.resolve(elem);
                                if (item.stopped) return;
                            }
                        }
    
                        const matches = target.$findAll(selector);
    
                        for (let index = 0; index < matches.length; index++) {
                            const match = matches[index];
    
                            if (!this.checked.has(match)) {
                                this.checked.add(match);
    
                                if (!filter || filter(match)) {
                                    this.resolve(match);
                                    if (this.stopped) return;
                                }
                            }
                        }
                    }
                };
    
                item.execute();
    
                if (!item.stopped) {
                    let observer = Observers.get(target);
    
                    if (!observer) {
                        observer = new MutationObserver(handleMuts);
                        Observers.set(target, observer);
    
                        observer.listeners = [];
                        observer.target = target;
    
                        observer.observe(target, { childList: true, subtree: true });
                    }
    
                    observer.listeners.push(item);
                }
            }
    
            const watchProto = {
                $watch(...args) {
                    const finishPromise = this.targetPromise.then(target => target.$watch(...args).finishPromise);
        
                    return {
                        targetPromise: this.targetPromise,
                        finishPromise,
        
                        parent: this.parent,
                        __proto__: watchProto
                    }
                },
                
                $watchLoop(...args) {
                    this.targetPromise.then(target => { target.$watchLoop(...args); });
                    return this;
                },
                
                $watchData(...args) {
                    this.targetPromise.then(target => { target.$watchData(...args); });
                    return this;
                },
        
                $then(callback) {
                    const nxt = {
                        targetPromise: this.finishPromise || this.targetPromise,
                        finishPromise: null,
                        
                        parent: this,
                        __proto__: watchProto
                    };
        
                    if (callback) nxt.targetPromise.then(callback);
                    return nxt;
                },
        
                $back() {
                    if (!this.parent) console.error("your at the top of the watcher");
                    return this.parent;
                },
        
                $promise() {
                    return (this.finishPromise || this.targetPromise);
                }
            };
        
            function handleMuts(muts, self) {
                const listeners = self.listeners;
                let index = 0;
        
                while (index < listeners.length) {
                    const item = listeners[index];
        
                    if (!item.stopped)
                        item.execute(muts);
        
                    if (item.stopped) 
                        listeners.splice(index, 1);
                    else
                        index++;
                }
        
                if (!listeners.length) {
                    self.disconnect();
                    Observers.delete(self.target);
                }
            }
            
            Object.assign($, {
                each(list, fn) { 
                    Array.prototype.forEach.call(list, fn);
                },
    
                ready(fn) {
                    if (document.readyState != "loading")
                        fn();
                    else
                        document.addEventListener("DOMContentLoaded", fn, { once: true });
                },
    
                watch(target, selectors, filter, callback) {
                    if (typeof callback != "function") {
                        callback = filter;
                        filter = null;
                    }
    
                    if ((target instanceof Document) || (target instanceof DocumentFragment)) {
                        target = target.documentElement;
                    }
    
                    if (!Array.isArray(selectors)) selectors = [selectors];
    
                    let finishPromise;
    
                    /*const promises = selectors.map(selector => addWatch(target, selector, filter));*/
                    const promises = selectors.map(selector => new Promise(resolve => addWatch(target, selector, filter, resolve)));
    
                    finishPromise = Promise.all(promises).then(elems => {
                        if (callback) {
                            try { callback(...elems); }
                            catch(ex) { console.error(selectors, ex); }
                        }
        
                        return elems[0];
                    });
    
                    return {
                        targetPromise: Promise.resolve(target),
                        finishPromise,
                        __proto__: watchProto
                    }
                },
                watchLoop(target, selector, filter, callback) {
    
                    if (typeof callback != "function") {
                        callback = filter;
                        filter = null;
                    }
    
                    if ((target instanceof Document) || (target instanceof DocumentFragment)) {
                        target = target.documentElement;
                    }
    
                    const item = {
                        checked: new WeakSet(),
                        stopped: false,
    
                        resolve(node) {
                            if (callback) {
                                try { callback(node, () => this.stopped = true); }
                                catch(ex) { console.error(selector, ex); }
                            }
                        },
    
                        execute() {
                            const matches = target.$findAll(selector);
    
                            for (const match of matches) {
                                if (this.checked.has(match) == false) {
                                    this.checked.add(match);
    
                                    if (!filter || filter(match)) {
                                        this.resolve(match);
                                        if (this.stopped) return;
                                    }
                                }
                            }
                        }
                    };
    
                    item.execute();
    
                    if (!item.stopped) {
                        let observer = Observers.get(target);
    
                        if (!observer) {
                            observer = new MutationObserver(handleMuts);
                            Observers.set(target, observer);
    
                            observer.listeners = [];
                            observer.target = target;
    
                            observer.observe(target, { childList: true, subtree: true });
                        }
    
                        observer.listeners.push(item);
                    }
                },
                watchData(target, filter, callback) {
    
                    if (typeof callback != "function") {
                        callback = filter;
                        filter = null;
                    }
    
                    if ((target instanceof Document) || (target instanceof DocumentFragment)) {
                        target = target.documentElement;
                    }
    
                    const item = {
                        checked: new WeakSet(),
                        stopped: false,
    
                        resolve(node) {
                            if (callback) {
                                try { callback(node, () => this.stopped = true); }
                                catch(ex) { console.error(ex); }
                            }
                        },
    
                        execute() {
                            if (!filter || filter(target)) {
                                this.resolve(target);
                                if (this.stopped) return;
                            }
                        }
                    };
    
                    item.execute();
    
                    if (!item.stopped) {
                        let observer = Observers.get(target);
    
                        if (!observer) {
                            observer = new MutationObserver(handleMuts);
                            Observers.set(target, observer);
    
                            observer.listeners = [];
                            observer.target = target;
    
                            observer.observe(target, { characterData: true, attributes: true, subtree: true });
                        }
    
                        observer.listeners.push(item);
                    }
                },
    
                find(self, selector, callback) {
                    let result = self.querySelector(selector);
                    if (callback != null && result != null) return (callback(result) || result);
                    return result;
                },
                findAll(self, selector, callback) {
                    let result = self.querySelectorAll(selector);
                    if (callback != null && result != null && result.length > 0) Array.prototype.forEach.call(result, callback);
                    return result;
                },
                clear(self) {
                    Array.prototype.forEach.call(self.childNodes, (node) => {
                        node.remove();
                    });
                    Array.prototype.forEach.call(self.children, (element) => {
                        element.remove();
                    });
                },
    
                on(self, events, selector, callback, config) {
                    if (typeof selector == "function") { [selector, callback, config] = [null, selector, callback]; }
                    if (!self.$events) { Object.defineProperty(self, "$events", { value: {} }); }
    
                    events.split(" ").forEach(eventType => {
                        eventType = eventType.trim();
    
                        const eventName = eventType.replace(/^([^.]+).*$/, "$1");
                        if (!eventName) return;
    
                        let listeners = self.$events[eventType];
                        if (!listeners) { listeners = self.$events[eventType] = []; }
    
                        const handler = event => {
                            if (!selector) return callback.call(self, event, self);
    
                            const fn = event.stopImmediatePropagation;
                            let immediateStop = false;
    
                            event.stopImmediatePropagation = function() {
                                immediateStop = true;
                                return fn.call(this);
                            };
    
                            const path = event.composedPath();
                            const maxIndex = path.indexOf(self);
                            for (let i = 0; i < maxIndex; i++) {
                                const node = path[i];
    
                                if (node.matches(selector)) {
                                    Object.defineProperty(event, "currentTarget", { value: node, configurable: true });
                                    callback.call(self, event, self);
                                    delete event.currentTarget;
    
                                    if (immediateStop) break;
                                }
                            }
    
                            delete event.stopImmediatePropagation;
                        };
    
                        const listener = {
                            selector, callback,
                            params: [eventName, handler, config]
                        };
    
                        listeners.push(listener);
                        self.addEventListener(...listener.params);
                    });
    
                    return self
                },
                triggerCustom(self, type, detail) {
                    self.dispatchEvent(new CustomEvent(type, { detail }));
                    return self;
                }
            });
            
            Assign([self.EventTarget, EventTarget], {
                $on(...args) { return $.on(this, ...args); },
                $triggerCustom(...args) { return $.triggerCustom(this, ...args); },
                $event(...args) { return $.triggerCustom(this, ...args); }
            });
    
            Assign([self.Element, Element, self.Document, Document, self.DocumentFragment, DocumentFragment], {
                $each(...args) { return $.each(this.children, ...args); },
                $find(...args) { return $.find(this, ...args); },
                $findAll(...args) { return $.findAll(this, ...args); },
                $clear() { return $.clear(this); },
                $watch(...args) { return $.watch(this, ...args); },
                $watchLoop(...args) { return $.watchLoop(this, ...args); },
                $watchData(...args) { return $.watchData(this, ...args); }
            });
    
            Assign([self.NodeList, NodeList], {
                $each(...args) { return $.each(this, ...args); }
            });
        } else {
            $ = {};
        }
    
        return $;
    })();
    
    //Unfinished
    converter = (() => {
        let cv = {};
    
        cv.directions = {
            //direction: [ left, top, right, bottom ]
            "center": [ true, true, true, true ],
            "middle": [ true, true, true, true ],
    
            "left": [ true, null, false, null ],
            "top": [ null, true, null, false ],
            "right": [ false, null, true, null ],
            "bottom": [ null, false, null, true ]
        };
    
        /*assigning multiple functions*/
        function Assign(stuff, data) { stuff.forEach(constructor => { Object.assign(constructor.prototype, data); }) }
    
        Object.assign(cv, {
            direction(dir) {
                if(obj == null) obj = "";
                var result = [ false, false, false, false ];
    
                if (dir.includes("center") || dir.includes("middle")) { result = [ true, true, true, true ]; }
                if (dir.includes("left")) { cv.directions["left"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }
                if (dir.includes("top")) { cv.directions["top"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }
                if (dir.includes("right")) { cv.directions["right"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }
                if (dir.includes("bottom")) { cv.directions["bottom"].forEach((state, face) => { if (state == null) { return; } result[face] = state; }); }
    
                return result;
            },
            fn(obj) {
                if (typeof obj == "function") return obj();
                return obj;
            },
            toInput(item, value, customInput) {
                // depending on item give the output needed for it
                // custom Itput if given
            }
        });
        
        return cv;
    })();

    const moduleConfig = getModuleConfig();

    function getModuleConfig() {
        return {
                   robuxChanger: {
                       enabled: JSON.parse(localStorage.getItem("BloxUtils.robuxChanger.enabled")) || false,
                       startingRobux: 30000000,
                   },
                   itemBuyer: {
                       enabled: JSON.parse(localStorage.getItem("BloxUtils.itemBuyer.enabled")) || false,
                       addToInventory: JSON.parse(localStorage.getItem("BloxUtils.itemBuyer.addToInventory")) || true
                   },
                   avatarChanger: {
                       enabled: JSON.parse(localStorage.getItem("BloxUtils.avatarChanger.enabled")) || false,
                       defaultAddedItems: JSON.parse(localStorage.getItem("BloxUtils.avatarChanger.defaultItems")) || []
                   },
                   codeRedeemer: {
                       enabled: JSON.parse(localStorage.getItem("BloxUtils.codeRedeemer.enabled")) || false,
                       promocodes: JSON.parse(localStorage.getItem("BloxUtils.codeRedeemer.promocodes")) || []
                   },
                   groupPayouts: {
                       enabled: JSON.parse(localStorage.getItem("BloxUtils.groupPayouts.enabled")) || false,
                       groupConfig: []
                   },
                   impersonate: {
                       enabled: JSON.parse(localStorage.getItem("BloxUtils.easyImpersonate.enabled")) || false,
                       userId: parseInt(localStorage.getItem("BloxUtils.easyImpersonate.id")) || 1
                   }
               }
    }

    let currentRobux;
    function checkRobux() {
        const robuxBalance =
              parseInt(localStorage.getItem("BloxUtils.robuxChanger.balance")) || 0;
        if(robuxBalance == moduleConfig.robuxChanger.startingRobux) {
            currentRobux = moduleConfig.robuxChanger.startingRobux;
        } else {
            currentRobux = robuxBalance;
        }
    }
    
    function getFunds(groupId) {
        const funds =
            parseInt(localStorage.getItem(`BloxUtils.groupPayouts.funds_${groupId}`)) || 0;
        return funds;
    }
    
    function deductFunds(groupId, deductAmount) {
        const funds =
            parseInt(localStorage.getItem(`BloxUtils.groupPayouts.funds_${groupId}`)) || 0;
        localStorage.setItem(`BloxUtils.groupPayouts.funds_${groupId}`, funds - parseInt(deductAmount));
        return true;
    }

    function addRobux(addAmount) {
        localStorage.setItem("BloxUtils.robuxChanger.balance", currentRobux + addAmount);
        return true;
    }

    function deductRobux(deductAmount) {
        localStorage.setItem("BloxUtils.robuxChanger.balance", currentRobux - deductAmount);
        return true;
    }

    function getOwnedCopies(itemId) {
        const ownedCopies =
              parseInt(localStorage.getItem(`BloxUtils_ownedCopies_${itemId}`)) || 0;
        return ownedCopies;
    };

    function addOwnedCopy(itemId) {
        const ownedCopies =
              parseInt(localStorage.getItem(`BloxUtils_ownedCopies_${itemId}`)) || 0;
        localStorage.setItem(`ownedCopies_${itemId}`, ownedCopies + 1);
        return true;
    };

    function getResellersToRemove(itemId) {
        const boughtItemResellers =
              JSON.parse(localStorage.getItem(`BloxUtils_boughtResellers_${itemId}`)) || [];
        return boughtItemResellers;
    }

    function addBoughtReseller(itemId, resellerId) {
        const boughtItemResellers =
              JSON.parse(localStorage.getItem(`BloxUtils_boughtResellers_${itemId}`)) || [];
        boughtItemResellers.push(resellerId);
        localStorage.setItem(`BloxUtils_boughtResellers_${itemId}`, JSON.stringify(boughtItemResellers));
    }

    function getPromocode(usedPromocode) {
        return moduleConfig.codeRedeemer.promocodes.find(promocode => promocode.code === usedPromocode);
    }

    function getExpectedSeller(itemId) {
        return new Promise((resolve, reject) => {
            fetch(`https://economy.roblox.com/v1/assets/${itemId}/resellers?cursor=&limit=10`, {
                credentials: "include",
                headers: {
                    Accept: "application/json, text/plain, */*",
                    "Accept-Language": "en-US,en;q=0.5",
                    "Sec-Fetch-Dest": "empty",
                    "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Site": "same-site",
                },
                referrer: "https://www.roblox.com/",
                method: "GET",
                mode: "cors",
            })
                .then((response) => response.json())
                .then((resellerData) => {
                    const expectedSellerData = resellerData;
                    const resellersToRemove = getResellersToRemove(itemId);
                    resellersToRemove.forEach(id => {
                        const index = expectedSellerData.data.findIndex(item => item.seller.id === id);
                        if (index !== -1) {
                            expectedSellerData.data.splice(index, 1);
                        }
                    });
                    let expectedSeller;
                    try {
                        expectedSeller = expectedSellerData.data[0];
                    } catch {
                        expectedSeller = null;
                    }
                    resolve(expectedSeller);
            })
        })
    };

    let IB_addedItems;

    function getBoughtItems() {
        const boughtItems =
              JSON.parse(localStorage.getItem("BloxUtils_boughtItems")) || [];
        return boughtItems;
    };

    function addBoughtItem(item) {
        const boughtItems =
              JSON.parse(localStorage.getItem("BloxUtils_boughtItems")) || [];
        boughtItems.push(item);
        localStorage.setItem("BloxUtils_boughtItems", JSON.stringify(boughtItems));
    }

    function setAddedItems() {
        const boughtItems = getBoughtItems();
        IB_addedItems = [...moduleConfig.avatarChanger.defaultAddedItems, ...boughtItems];
    }

    function getRenderData(impersonateEnabled, impersonateOwned) {
        return new Promise((resolve, reject) => {
            const avatarUrl = moduleConfig.impersonate.enabled ? `https://avatar.roblox.com/v1/users/${moduleConfig.impersonate.userId}/avatar` : "https://avatar.roblox.com/v1/avatar";
            fetch(avatarUrl, {
                credentials: "include",
                headers: {
                    Accept: "application/json, text/plain, */*",
                    "Accept-Language": "en-US,en;q=0.5",
                    "Sec-Fetch-Dest": "empty",
                    "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Site": "same-site",
                },
                referrer: "https://www.roblox.com/",
                method: "GET",
                mode: "cors",
            })
                .then((response) => response.json())
                .then((avatarData) => {
                    const assets = [];
                    const equippedItems = getEquipped(moduleConfig.impersonate.enabled, impersonateOwned);
                    equippedItems.forEach((item) =>
                        assets.push({ id: item.id })
                    );
                    if(!impersonateEnabled) {
                        avatarData.assets.forEach((asset) => {
                            const assetData = { id: asset.id };
                            if (asset.meta) {
                                assetData.meta = asset.meta;
                            }
                            assets.push(assetData);
                        });
                    }

                    const bodyColors = avatarData.bodyColors;
                    const headColor = convertColor(bodyColors.headColorId);
                    const leftArmColor = convertColor(bodyColors.leftArmColorId);
                    const leftLegColor = convertColor(bodyColors.leftLegColorId);
                    const torsoColor = convertColor(bodyColors.torsoColorId);
                    const rightLegColor = convertColor(bodyColors.rightLegColorId);
                    const rightArmColor = convertColor(bodyColors.rightArmColorId);

                    const renderDataRes = {
                        thumbnailConfig: {
                            thumbnailId: 2,
                            thumbnailType: "2d",
                            size: "352x352",
                        },
                        avatarDefinition: {
                            assets: assets,
                            bodyColors: {
                                headColor: headColor,
                                leftArmColor: leftArmColor,
                                leftLegColor: leftLegColor,
                                rightArmColor: rightArmColor,
                                rightLegColor: rightLegColor,
                                torsoColor: torsoColor,
                            },
                            scales: avatarData.scales,
                            playerAvatarType: {
                                playerAvatarType: avatarData.playerAvatarType,
                            },
                        },
                    };
                    resolve(renderDataRes);
                })
                .catch((error) => {
                    reject(error);
                });
        });
    }

    function convertColor(colorNumber) {
        /* Convert a roblox color ID to a HEX color code. */
        const conversions = {"1": "#F2F3F3", "2": "#A1A5A2", "3": "#F9E999", "5": "#D7C59A", "6": "#C2DAB8", "9": "#E8BAC8", "11": "#80BBDB", "12": "#CB8442", "18": "#CC8E69", "21": "#C4281C", "22": "#C470A0", "23": "#0D69AC", "24": "#F5CD30", "25": "#624732", "26": "#1B2A35", "27": "#6D6E6C", "28": "#287F47", "29": "#A1C48C", "36": "#F3CF9B", "37": "#4B974B", "38": "#A05F35", "39": "#C1CADE", "40": "#ECECEC", "41": "#CD544B", "42": "#C1DFF0", "43": "#7BB6E8", "44": "#F7F18D", "45": "#B4D2E4", "47": "#D9856C", "48": "#84B68D", "49": "#F8F184", "50": "#ECE8DE", "100": "#EEC4B6", "101": "#DA867A", "102": "#6E99CA", "103": "#C7C1B7", "104": "#6B327C", "105": "#E29B40", "106": "#DA8541", "107": "#008F9C", "108": "#685C43", "110": "#435493", "111": "#BFB7B1", "112": "#6874AC", "113": "#E5ADC8", "115": "#C7D23C", "116": "#55A5AF", "118": "#B7D7D5", "119": "#A4BD47", "120": "#D9E4A7", "121": "#E7AC58", "123": "#D36F4C", "124": "#923978", "125": "#EAB892", "126": "#A5A5CB", "127": "#DCBC81", "128": "#AE7A59", "131": "#9CA3A8", "133": "#D5733D", "134": "#D8DD56", "135": "#74869D", "136": "#877C90", "137": "#E09864", "138": "#958A73", "140": "#203A56", "141": "#27462D", "143": "#CFE2F7", "145": "#7988A1", "146": "#958EA3", "147": "#938767", "148": "#575857", "149": "#161D32", "150": "#ABADAC", "151": "#789082", "153": "#957977", "154": "#7B2E2F", "157": "#FFF67B", "158": "#E1A4C2", "168": "#756C62", "176": "#97695B", "178": "#B48455", "179": "#898788", "180": "#D7A94B", "190": "#F9D62E", "191": "#E8AB2D", "192": "#694028", "193": "#CF6024", "194": "#A3A2A5", "195": "#4667A4", "196": "#23478B", "198": "#8E4285", "199": "#635F62", "200": "#828A5D", "208": "#E5E4DF", "209": "#B08E44", "210": "#709578", "211": "#79B5B5", "212": "#9FC3E9", "213": "#6C81B7", "216": "#904C2A", "217": "#7C5C46", "218": "#96709F", "219": "#6B629B", "220": "#A7A9CE", "221": "#CD6298", "222": "#E4ADC8", "223": "#DC9095", "224": "#F0D5A0", "225": "#EBB87F", "226": "#FDEA8D", "232": "#7DBBDD", "268": "#342B75", "301": "#506D54", "302": "#5B5D69", "303": "#0010B0", "304": "#2C651D", "305": "#527CAE", "306": "#335882", "307": "#102ADC", "308": "#3D1585", "309": "#348E40", "310": "#5B9A4C", "311": "#9FA1AC", "312": "#592259", "313": "#1F801D", "314": "#9FADC0", "315": "#0989CF", "316": "#7B007B", "317": "#7C9C6B", "318": "#8AAB85", "319": "#B9C4B1", "320": "#CACBD1", "321": "#A75E9B", "322": "#7B2F7B", "323": "#94BE81", "324": "#A8BD99", "325": "#DFDFDE", "327": "#970000", "328": "#B1E5A6", "329": "#98C2DB", "330": "#FF98DC", "331": "#FF5959", "332": "#750000", "333": "#EFB838", "334": "#F8D96D", "335": "#E7E7EC", "336": "#C7D4E4", "337": "#FF9494", "338": "#BE6862", "339": "#562424", "340": "#F1E7C7", "341": "#FEF3BB", "342": "#E0B2D0", "343": "#D490BD", "344": "#965555", "345": "#8F4C2A", "346": "#D3BE96", "347": "#E2DCBC", "348": "#EDEAEA", "349": "#E9DADA", "350": "#883E3E", "351": "#BC9B5D", "352": "#C7AC78", "353": "#CABFA3", "354": "#BBB3B2", "355": "#6C584B", "356": "#A0844F", "357": "#958988", "358": "#ABA89E", "359": "#AF9483", "360": "#966766", "361": "#564236", "362": "#7E683F", "363": "#69665C", "364": "#5A4C42", "365": "#6A3909", "1001": "#F8F8F8", "1002": "#CDCDCD", "1003": "#111111", "1004": "#FF0000", "1005": "#FFB000", "1006": "#B480FF", "1007": "#A34B4B", "1008": "#C1BE42", "1009": "#FFFF00", "1010": "#0000FF", "1011": "#002060", "1012": "#2154B9", "1013": "#04AFEC", "1014": "#AA5500", "1015": "#AA00AA", "1016": "#FF66CC", "1017": "#FFAF00", "1018": "#12EED4", "1019": "#00FFFF", "1020": "#00FF00", "1021": "#3A7D15", "1022": "#7F8E64", "1023": "#8C5B9F", "1024": "#AFDDFF", "1025": "#FFC9C9", "1026": "#B1A7FF", "1027": "#9FF3E9", "1028": "#CCFFCC", "1029": "#FFFFCC", "1030": "#FFCC99", "1031": "#6225D1"}
        return conversions[colorNumber.toString()]
    }

    async function getItemsInfo(itemIds, csrfToken) {
        const items = []
        itemIds.forEach((id) => {
            items.push({
                "itemType": 1,
                "id": id
            })
        })
        const itemsBody = {"items": items}
        return new Promise((resolve, reject) => {
        fetch("https://catalog.roblox.com/v1/catalog/items/details", {
            credentials: "include",
            headers: {
                Accept: "application/json, text/plain, */*",
                "Accept-Language": "en-US,en;q=0.5",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-site",
                "x-csrf-token": csrfToken
            },
            referrer: "https://www.roblox.com/",
            method: "POST",
            mode: "cors",
            body: JSON.stringify(itemsBody)
        })
            .then((response) => response.json())
            .then((itemsData) => {
                resolve(itemsData);
            })
        });
    }
    
    async function getCurrentlyEquipped(userId) {
        return new Promise((resolve, reject) => {
        fetch(`https://avatar.roblox.com/v1/users/${moduleConfig.impersonate.userId}/currently-wearing`, {
            credentials: "include",
            headers: {
                Accept: "application/json, text/plain, */*",
                "Accept-Language": "en-US,en;q=0.5",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-site",
            },
            referrer: "https://www.roblox.com/",
            method: "GET",
            mode: "cors",
        })
            .then((response) => response.json())
            .then((equippedData) => {
                resolve(equippedData);
            })
        })
    }

    async function renderAvatar(csrfToken, renderData) {
        function fetchData() {
            return fetch("https://avatar.roblox.com/v1/avatar/render", {
                credentials: "include",
                headers: {
                    Accept: "application/json, text/plain, */*",
                    "Accept-Language": "en-US,en;q=0.5",
                    "Sec-Fetch-Dest": "empty",
                    "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Site": "same-site",
                    "x-csrf-token": csrfToken,
                    "content-type": "application/json;charset=UTF-8",
                },
                referrer: "https://www.roblox.com/",
                method: "POST",
                body: JSON.stringify(renderData),
                mode: "cors",
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.state === "Pending") {
                        return new Promise((resolve) =>
                            setTimeout(resolve, 1000)
                        ).then(fetchData);
                    } else if (data.state === "Completed") {
                        return data;
                    }
                });
        }

        return fetchData();
    }

    function getItemChanges(rawEquipData, impersonateEnabled, impersonateOwned) {
        const equipData = JSON.parse(rawEquipData);
        const equipped = [];
        const unequipped = [];
        if(impersonateEnabled) {
            equipData.assets.forEach((asset) => {
                const ownedAssets = impersonateOwned.data;
                const ownedAssetIDs = ownedAssets.map((item) => parseInt(item.id));
                if(ownedAssetIDs.includes(asset.id)) {
                    equipped.push(asset);
                }
            });
            
            const equippedData = equipped.map((equippedItem) => ({
                id: equippedItem.id,
                name: equippedItem.name,
            }));
            setEquipped(equippedData, moduleConfig.impersonate.enabled);
            return;  
        } else {
            equipData.assets.forEach((asset) => {
                const addedItemIDs = IB_addedItems.map((item) => parseInt(item.id));
                if (addedItemIDs.includes(asset.id)) {
                    equipped.push(asset);
                }
            });
    
            const equippedData = equipped.map((equippedItem) => ({
                id: equippedItem.id,
                name: equippedItem.name,
            }));
            setEquipped(equippedData);
            return;
        }
    }

    function getEquipped(impersonateEnabled, impersonateOwned) {
        if(impersonateEnabled) {
            const impersonateEquipped =
                JSON.parse(localStorage.getItem("BloxUtils.impersonateEquipped")) || impersonateOwned;
            return impersonateEquipped;
        } else {
            const equippedItems =
                JSON.parse(localStorage.getItem("BloxUtils_equippedItems")) || [];
            return equippedItems;
        }
    }

    function setEquipped(equippedItems, impersonateEnabled) {
        if(impersonateEnabled) {
            localStorage.setItem("BloxUtils.impersonateEquipped", JSON.stringify(equippedItems));
            return true;
        } else {
            localStorage.setItem("BloxUtils_equippedItems", JSON.stringify(equippedItems));
            return true;
        }
    }

    const _response = Object.getOwnPropertyDescriptor(
        XMLHttpRequest.prototype,
        "response"
    );
    const _status = Object.getOwnPropertyDescriptor(
        XMLHttpRequest.prototype,
        "status"
    );
    const _responseText = Object.getOwnPropertyDescriptor(
        XMLHttpRequest.prototype,
        "responseText"
    );
    const xhrFunctions = {
        open: XMLHttpRequest.prototype.open,
        send: XMLHttpRequest.prototype.send,
        setRequestHeader: XMLHttpRequest.prototype.setRequestHeader
    };
    const _XMLHttpRequest = XMLHttpRequest;

    class BloxUtilsXhr extends _XMLHttpRequest {
        constructor(...args) {
            super(...args);
            this._open = xhrFunctions.open;
            this._send = xhrFunctions.send;
            this._setRequestHeader = xhrFunctions.setRequestHeader;


            /* Data */
            this.csrfToken = null;
            this.requestUrl = null;
            this.resellerId = null;
            this.requestData = null;
            this.batchRequest = false;
            this.expectedSeller = null;
            this.purchaseAmount = null;
            this.batchRenderedData = {};

            /* Changes */
            this.promocode = null;
            this.roleChange = false;
            this.fundsChange = false;
            this.batchChange = false;
            this.equipChange = false;
            this.payoutChange = false;
            this.avatarChange = false;
            this.redeemChange = false;
            this.settingsChange = false;
            this.equippedChange = false;
            this.purchaseChange = false;
            this.itemInfoChange = false;
            this.groupInfoChange = false;
            this.resellersChange = false;
            this.inventoryChange = false;
            this.eligibilityChange = false;
            this.restrictionChange = false;
            this.conversationsChange = false;
            this.groupMembershipChange = false;

            Object.defineProperty(this, "status", {
                get: function () {
                    if (this.currencyChange) {
                        return 200;
                    } else if (this.purchaseChange) {
                        return 200;
                    } else if (this.avatarChange) {
                        return 200;
                    } else if (this.equipChange) {
                        return 200;
                    } else if (this.redeemChange){
                        return 200;
                    } else if (this.payoutChange) {
                        return 200;
                    } else {
                        return _status.get.call(this);
                    }
                },
                configurable: true,
            });
            Object.defineProperty(this, "response", {
                get: function () {
                    if (this.currencyChange) {
                        return {"robux": currentRobux};
                    } else if (this.purchaseChange) {
                        return {
                            purchaseResult: "Purchase transaction success",
                            purchased: true,
                            pending: false,
                            errorMessage: null,
                        };
                    } else if(this.resellersChange) {
                        const resellersData = JSON.parse(_response.get.call(this));
                        const itemId = window.location.href.split("/")[4];
                        const resellersToRemove = getResellersToRemove(itemId);
                        resellersToRemove.forEach(id => {
                            const index = resellersData.data.findIndex(item => item.seller.id === id);
                            if (index !== -1) {
                                resellersData.data.splice(index, 1);
                            }
                        });
                        return resellersData;
                    } else if (this.avatarChange) {
                        let currentAvatarItems = JSON.parse(
                            _response.get.call(this)
                        );
                        const newAddedItems = [];
                        IB_addedItems.forEach((item) => {
                            newAddedItems.push({
                                id: item.id,
                                name: item.name,
                                type: "Asset",
                                assetType: { id: 8, name: "Hat" },
                            });
                        });
                        const newItems = {
                            data: [
                                ...newAddedItems,
                                ...currentAvatarItems.data,
                            ],
                        };
                        if(moduleConfig.impersonate.enabled) {
                            const userItems = this.impersonateUserItems.data;
                            const impersonateItems = [];
                            userItems.forEach((item) => {
                                impersonateItems.push({
                                    id: item.id,
                                    name: item.name,
                                    type: item.itemType,
                                    assetType: {
                                        id: item.assetType,
                                        name: "Hat"
                                    }
                                })
                            })
                            const newItems = {
                                data: impersonateItems
                            };
                            return newItems;
                        } else {
                            return newItems;
                        }
                    } else if (this.equipChange) {
                        return {
                            invalidAssets: [],
                            invalidAssetIds: [],
                            success: true,
                        };
                    } else if(this.conversationsChange) {
                        return [];
                    } else if(this.roleChange) {
                          const originalRoles = JSON.parse(_response.get.call(this));
                          const groupId = parseInt(window.location.href.split("=")[1].split("#")[0]);
                          console.log(groupId)
                          originalRoles.data.push({"group": {
                              "id": groupId,
                              "name": "x",
                              "memberCount": 1,
                              "hasVerifiedBadge": false
                          },
                              "role": {
                                  "id": 1,
                                  "name": "Member",
                                  "rank": 1
                              }
                          })
                          return originalRoles
                    } else if(this.eligibilityChange) {
                        const userId = parseInt(this.requestUrl.split("=")[1]);
                        const eligibility = {"usersGroupPayoutEligibility": {}}
                        eligibility.usersGroupPayoutEligibility[userId] = "Eligible";
                        return eligibility;
                    } else if(this.groupMembershipChange) {
                        return {
                                   "groupId": 145864,
                                   "isPrimary": false,
                                   "isPendingJoin": false,
                                   "userRole": {
                                       "user": {
                                           "hasVerifiedBadge": false,
                                           "userId": 3424211266,
                                           "username": "ElijahNFT",
                                           "displayName": "Axix"
                                       },
                                       "role": {
                                           "id": 779579,
                                           "name": "Owner",
                                           "rank": 255
                                       }
                                   },
                                   "permissions": {
                                       "groupPostsPermissions": {
                                           "viewWall": true,
                                           "postToWall": true,
                                           "deleteFromWall": true,
                                           "viewStatus": true,
                                           "postToStatus": true
                                       },
                                       "groupMembershipPermissions": {
                                           "changeRank": true,
                                           "inviteMembers": true,
                                           "removeMembers": true
                                       },
                                       "groupManagementPermissions": {
                                           "manageRelationships": true,
                                           "manageClan": true,
                                           "viewAuditLogs": true
                                       },
                                       "groupEconomyPermissions": {
                                           "spendGroupFunds": true,
                                           "advertiseGroup": true,
                                           "createItems": true,
                                           "manageItems": true,
                                           "addGroupPlaces": true,
                                           "manageGroupGames": true,
                                           "viewGroupPayouts": true,
                                           "viewAnalytics": true
                                       },
                                       "groupOpenCloudPermissions": {
                                           "useCloudAuthentication": true,
                                           "administerCloudAuthentication": true
                                       }
                                   },
                                   "areGroupGamesVisible": true,
                                   "areGroupFundsVisible": true,
                                   "areEnemiesAllowed": true,
                                   "canConfigure": true
                               }
                    } else if (this.equippedChange) {
                        const originalResponse = JSON.parse(
                            _response.get.call(this)
                        );
                        const equippedItems = getEquipped(moduleConfig.impersonate.enabled, this.impersonateUserItems.data);
                        equippedItems.forEach((item) => {
                            originalResponse.assets.push({
                                id: item.id,
                                name: item.name,
                                assetType: {
                                    id: item.assetType ? item.assetType : "Hat",
                                    name: "Hat",
                                },
                            });
                        });
                        return originalResponse;
                    } else if(this.groupInfoChange) {
                        const groupDescription = "Welcome To My Roblox's Group";
                          return {
                              "id": 1,
                              "name":"Wings",
                              "description": groupDescription,
                              "owner":{"hasVerifiedBadge":true,"userId": 1,"username":"Stickmasterluke","displayName":"Stickmasterluke"},
                              "shout": {
                                  "body":"I'm giving ROBUX to Everyone who Comments their Username on the Group Wall!",
                                  "poster":{
                                      "hasVerifiedBadge":false,"userId":3424211266,"username":"ElijahNFT","displayName":"Axix"
                                  },
                              "created":"2022-11-06T19:29:21.13Z",
                              "updated":"2023-06-04T21:26:42.493Z"},
                              "memberCount":8418,
                              "isBuildersClubOnly":false,
                              "publicEntryAllowed":true,
                              "hasVerifiedBadge":false
                          };
                    } else if(this.fundsChange) {
                            const groupId = this.requestUrl.split("/")[5];
                            const funds = getFunds(groupId);
                            return {"robux": funds};
                    } else if(this.restrictionChange) {
                            return {"canUseRecurringPayout": true,"canUseOneTimePayout": true};
                    } else if(this.settingsChange) {
                            let userId = 80254;
                            let name = "Stickmasterluke";
                            let displayName = "Stickmasterluke";
                            document.$watch(".form-group[ng-if='accountSettingsPolicy.displayPhoneNumber && accountInfoSettings.isPhoneNumberVisible']", (phoneSetting) => {
                                phoneSetting.remove();
                            })
                            return {
                                   "ChangeUsernameEnabled": true,
                                   "IsAdmin": true,
                                   "UserId": userId,
                                   "Name": name,
                                   "DisplayName": displayName,
                                   "IsEmailOnFile": true,
                                   "IsEmailVerified": true,
                                   "IsPhoneFeatureEnabled": true,
                                   "RobuxRemainingForUsernameChange": 99999999,
                                   "PreviousUserNames": "Stickmasterwho",
                                   "UseSuperSafePrivacyMode": false,
                                   "IsAppChatSettingEnabled": true,
                                   "IsGameChatSettingEnabled": true,
                                   "IsParentalSpendControlsEnabled": true,
                                   "IsSetPasswordNotificationEnabled": false,
                                   "ChangePasswordRequiresTwoStepVerification": false,
                                   "ChangeEmailRequiresTwoStepVerification": false,
                                   "UserEmail": "s***********@gmail.com",
                                   "UserEmailMasked": true,
                                   "UserEmailVerified": true,
                                   "CanHideInventory": true,
                                   "CanTrade": true,
                                   "MissingParentEmail": false,
                                   "IsUpdateEmailSectionShown": true,
                                   "IsUnder13UpdateEmailMessageSectionShown": false,
                                   "IsUserConnectedToFacebook": false,
                                   "IsTwoStepToggleEnabled": false,
                                   "AgeBracket": 0,
                                   "UserAbove13": true,
                                   "ClientIpAddress": "127.0.0.1",
                                   "AccountAgeInDays": 3499,
                                   "IsPremium": true,
                                   "IsBcRenewalMembership": false,
                                   "PremiumFeatureId": null,
                                   "HasCurrencyOperationError": false,
                                   "CurrencyOperationErrorMessage": null,
                                   "Tab": null,
                                   "ChangePassword": false,
                                   "IsAccountPinEnabled": true,
                                   "IsAccountRestrictionsFeatureEnabled": true,
                                   "IsAccountRestrictionsSettingEnabled": false,
                                   "IsAccountSettingsSocialNetworksV2Enabled": false,
                                   "IsUiBootstrapModalV2Enabled": true,
                                   "IsDateTimeI18nPickerEnabled": true,
                                   "InApp": false,
                                   "MyAccountSecurityModel": {
                                       "IsEmailSet": true,
                                       "IsEmailVerified": true,
                                       "IsTwoStepEnabled": true,
                                       "ShowSignOutFromAllSessions": true,
                                       "TwoStepVerificationViewModel": {
                                           "UserId": 3424211266,
                                           "IsEnabled": true,
                                           "CodeLength": 0,
                                           "ValidCodeCharacters": null
                                       }
                                   },
                                   "ApiProxyDomain": "https://api.roblox.com",
                                   "AccountSettingsApiDomain": "https://accountsettings.roblox.com",
                                   "AuthDomain": "https://auth.roblox.com",
                                   "IsDisconnectFacebookEnabled": true,
                                   "IsDisconnectXboxEnabled": true,
                                   "NotificationSettingsDomain": "https://notifications.roblox.com",
                                   "AllowedNotificationSourceTypes": [
                                       "Test",
                                       "FriendRequestReceived",
                                       "FriendRequestAccepted",
                                       "PartyInviteReceived",
                                       "PartyMemberJoined",
                                       "ChatNewMessage",
                                       "PrivateMessageReceived",
                                       "UserAddedToPrivateServerWhiteList",
                                       "ConversationUniverseChanged",
                                       "TeamCreateInvite",
                                       "GameUpdate",
                                       "DeveloperMetricsAvailable",
                                       "GroupJoinRequestAccepted",
                                       "Sendr",
                                       "ExperienceInvitation"
                                   ],
                                   "AllowedReceiverDestinationTypes": [
                                       "DesktopPush",
                                       "NotificationStream"
                                   ],
                                   "BlacklistedNotificationSourceTypesForMobilePush": [],
                                   "MinimumChromeVersionForPushNotifications": 50,
                                   "PushNotificationsEnabledOnFirefox": true,
                                   "LocaleApiDomain": "https://locale.roblox.com",
                                   "HasValidPasswordSet": true,
                                   "IsFastTrackAccessible": false,
                                   "HasFreeNameChange": false,
                                   "IsAgeDownEnabled": true,
                                   "IsDisplayNamesEnabled": true,
                                   "IsBirthdateLocked": false
                               }
                    } else {
                        return _response.get.call(this);
                    }
                },
                configurable: true,
            });
            Object.defineProperty(this, "responseText", {
                get: function () {
                    if (this.currencyChange) {
                        return {"robux": currentRobux};
                    } else if (this.purchaseChange) {
                        const response = JSON.parse(_response.get.call(this));
                        const productId = this.requestUrl.split("/")[6];
                        const itemId = window.location.href.split("/")[4];
                        addOwnedCopy(itemId);
                        if(moduleConfig.itemBuyer.addToInventory) {
                            addBoughtItem({
                                id: itemId
                            });
                        };
                        addBoughtReseller(itemId, this.resellerId);
                        deductRobux(this.purchaseAmount);
                        return {
                            purchased: true,
                            reason: "Success",
                            productId: productId,
                            currency: 1,
                            assetId: null,
                            assetName: "",
                            assetType: "Hat",
                            assetTypeDisplayName: "Hat",
                            assetIsWearable: true,
                            sellerName: "",
                            transactionVerb: "bought",
                            isMultiPrivateSale: false,
                        };
                    } else if(this.itemInfoChange) {
                        const response = JSON.parse(_response.get.call(this));
                        const newResponse = response;
                        newResponse.owned = true;
                        const itemId = window.location.href.split("/")[4];
                        console.log("Expected Seller from RT", this.expectedSeller);
                        newResponse.lowestPrice = this.expectedSeller.price;
                        newResponse.lowestResalePrice = this.expectedSeller.price;
                        newResponse.expectedSellerId = this.expectedSeller.seller.id;
                        return newResponse;
                    } else if(this.inventoryChange) {
                        const itemId = window.location.href.split("/")[4];
                        const ownedItems = getOwnedCopies(itemId);
                        const inventoryData = {"previousPageCursor":null,"nextPageCursor":null,"data":[]}
                        for (let i = 0; i < ownedItems; i++) {
                            inventoryData.data.push({"type": "Asset", "id": 0, "name": "OWNED_ITEM", "instanceId": 0});
                        }
                        return inventoryData;
                    } else if(this.resellersChange) {
                        const resellersData = JSON.parse(_response.get.call(this));
                        const itemId = window.location.href.split("/")[4];
                        const resellersToRemove = getResellersToRemove(itemId);
                        resellersToRemove.forEach(id => {
                            const index = resellersData.data.findIndex(item => item.seller.id === id);
                            if (index !== -1) {
                                resellersData.data.splice(index, 1);
                            }
                        });
                        return resellersData;
                    } else if (this.batchChange) {
                        const imageUrl = this.batchRenderedData.imageUrl;

                        const originalResponse = JSON.parse(
                            _response.get.call(this)
                        );
                        if(imageUrl) {
                            if (originalResponse.data.length > 1) {
                                originalResponse.data[1].imageUrl = imageUrl;
                            } else {
                                originalResponse.data[0].imageUrl = imageUrl;
                            }
                        };
                        return originalResponse;
                    } else if(this.redeemChange){
                        const code = getPromocode(this.promocode);
                        if(!code) {
                            return {
                                errors: [
                                    { code: 20, message: null, userFacingMessage: null, fieldData: "" },
                                ],
                                redemptionResult: null,
                            };
                        } else {
                            if(code.type == "item") {
                                if (code.reward.giveItem) {
                                    addBoughtItem({
                                        id: code.reward.item
                                    });
                                };
                                return {
                                    errors: null,
                                    redemptionResult: {
                                        balanceAmountInLocalCurrency: 0.0,
                                        creatorName: "Roblox",
                                        error: "0",
                                        grantedRobux: "0",
                                        itemId: code.reward.item,
                                        itemName: code.reward.name,
                                        itemType: "Asset",
                                        itemTypeDisplayName: "Hat",
                                        redeemedCredit: 0.0,
                                        redeemedCreditInLocalCurrency: 0.0,
                                        successMsg: "You have successfully redeemed your gift card!",
                                        successSubText: "Successfully added 0 to your Robux balance",
                                    },
                                };
                            } else if(code.type == "robux") {
                                addRobux(code.amount);
                                return {
                                    errors: null,
                                    redemptionResult: {
                                        balanceAmountInLocalCurrency: 0,
                                        error: "0",
                                        grantedRobux: code.amount.toLocaleString(),
                                        redeemedCredit: 0,
                                        redeemedCreditInLocalCurrency: 0,
                                        successMsg: "You have successfully redeemed your gift card!",
                                        successSubText: "Successfully added 1,000 to your Robux balance",
                                    },
                                }
                            }
                        }
                    } else {
                        return _responseText.get.call(this);
                    }
                },
                configurable: true,
            });
        }

        setRequestHeader(...args) {
            if (args[0] == "x-csrf-token") {
                this.csrfToken = args[1];
            }
            return this._setRequestHeader.apply(this, args);
        }

        send(...args) {
            if(this.purchaseChange) {
                this.purchaseAmount = JSON.parse(args[0]).expectedPrice;
                this.resellerId = JSON.parse(args[0]).expectedSellerId;
                return this._send.apply(this, args);
            } else if(this.itemInfoChange) {
                const itemId = window.location.href.split("/")[4];
                getExpectedSeller(itemId).then((expectedSeller) => {
                    this.expectedSeller = expectedSeller;
                    console.log("Got expected seller");
                    if(this.expectedSeller) {
                        return this._send.apply(this, args);
                    }
                })
            } else if (this.batchRequest) {
                console.log("Batch Request: ", args[0])
                        this.requestData = args[0];
                        const dataMeta = document.querySelector(`meta[name="user-data"]`)
                        const userID = dataMeta.getAttribute("data-userid")
                        if (
                            args[0].includes(
                                `"requestId":"${userID}:undefined:Avatar:352x352:null:regular","type":"Avatar","targetId":"${userID}","format":null,"size":"352x352"`
                            )
                            && this.avatarBatch
                            && !args[0].includes("headshot")
                            && !moduleConfig.impersonate.enabled
                        ) {
                            getRenderData().then((renderData) => {
                                this.batchChange = true;
                                const originalResponse = _response.get.call(this);
                                renderAvatar(this.csrfToken, renderData).then(
                                    (data) => {
                                        console.log(
                                            `Completed rendering (image url: ${data.imageUrl})`
                                        );
                                        this.batchRenderedData = data;
                                        if (data) {
                                            try {
                                                return this._send.apply(this, args);
                                            } catch {
                                            }
                                        }
                                    }
                        );
                    });
            } else if (
                              args[0].includes(
                                  `"requestId":"${userID}:undefined:Avatar:352x352:null:regular","type":"Avatar","targetId":"${userID}","format":null,"size":"352x352"`
                              )
                              && !args[0].includes("headshot")
                              && moduleConfig.impersonate.enabled
                          ) {
                              console.log("Batch request (without Headshot request) -> Rendering.")
                              
                              getCurrentlyEquipped(moduleConfig.impersonate.userId).then((currentlyEquipped) => {
                                  const csrfToken = document.querySelector("meta[name='csrf-token']").dataset.token;
                                  getItemsInfo(currentlyEquipped.assetIds, csrfToken).then((itemsInfo) => {
                                      this.impersonateUserItems = itemsInfo;
                              console.log("Got Impersonate Data. Now Rendering")
                              console.log(this.impersonateUserItems.data);
                              
                              getRenderData(moduleConfig.impersonate.enabled, this.impersonateUserItems.data).then((renderData) => {
                                  this.batchChange = true;
                                  const originalResponse = _response.get.call(this);
                                  
                                  renderAvatar(this.csrfToken, renderData).then(
                                      (data) => {
                                          console.log(
                                              `Completed rendering (image url: ${data.imageUrl})`
                                          );
                                          this.batchRenderedData = data;
                                          if (data) {
                                              try {
                                                  const batchRequest = JSON.parse(args[0]);
                                                  const updatedBatch = batchRequest.map(item => {
                                                    if (item.type === "AvatarHeadShot" && item.targetId == window.userId) {
                                                      return { ...item, targetId: moduleConfig.impersonate.userId };
                                                    }
                                                    return item;
                                                  });
                                                  return this._send.apply(this, [JSON.stringify(updatedBatch)]);
                                              } catch {
                                              }
                                          }
                                      }
                          );
                      });
                        })
                      })
              } else if (
                                args[0].includes("Headshot")
                                && moduleConfig.impersonate.enabled
                            ) {
                                console.log("HEADSHOT Request")
                                const batchRequest = JSON.parse(args[0]);
                                const updatedBatch = batchRequest.map(item => {
                                  if (item.type === "AvatarHeadShot" && item.targetId == window.userId) {
                                    return { ...item, targetId: moduleConfig.impersonate.userId };
                                  }
                                  return item;
                                });
                                return this._send.apply(this, [JSON.stringify(updatedBatch)])
                }
            else {
                return this._send.apply(this, args);
            };
            } else if (this.equipChange) {
                getCurrentlyEquipped(moduleConfig.impersonate.userId).then((currentlyEquipped) => {
                    const csrfToken = document.querySelector("meta[name='csrf-token']").dataset.token;
                    getItemsInfo(currentlyEquipped.assetIds, csrfToken).then((itemsInfo) => {
                        this.impersonateUserItems = itemsInfo;
                        const changes = getItemChanges(args[0], moduleConfig.impersonate.enabled, itemsInfo);
                        return this._send.apply(this, args);
                    })
                })
            } else if(this.equippedChange) {
                getCurrentlyEquipped(moduleConfig.impersonate.userId).then((currentlyEquipped) => {
                    const csrfToken = document.querySelector("meta[name='csrf-token']").dataset.token;
                    getItemsInfo(currentlyEquipped.assetIds, csrfToken).then((itemsInfo) => {
                        this.impersonateUserItems = itemsInfo;
                        return this._send.apply(this, args);
                    })
                })
            } else if(this.avatarChange && moduleConfig.impersonate.enabled) {
                console.log("Getting currently equipped")
                getCurrentlyEquipped(moduleConfig.impersonate.userId).then((currentlyEquipped) => {
                    console.log("Getting items info")
                    const csrfToken = document.querySelector("meta[name='csrf-token']").dataset.token;
                    getItemsInfo(currentlyEquipped.assetIds, csrfToken).then((itemsInfo) => {
                        this.impersonateUserItems = itemsInfo;
                        return this._send.apply(this, args);
                    })
                })
            } else if(this.redeemChange) {
                const data = JSON.parse(args[0]);
                this.promocode = data.pinCode;
                return this._send.apply(this, args);
            } else if(this.payoutChange) {
                const robuxAmount = JSON.parse(args[0]).Recipients[0].amount;
                const groupId = this.requestUrl.split("/")[5];
                deductFunds(groupId, robuxAmount);
                return this._send.apply(this, args);
            } else {
                return this._send.apply(this, args);
            }
        }

        open(...args) {
            /* BloxUtilsXhr.open
            Determines which modifications to make.
            */
            if (args[1].includes("/currency") && args[1].includes("/users") && moduleConfig.robuxChanger.enabled) {
                this.currencyChange = true;
            };
            
            if (args[1].includes("v1/batch")) {
                this.batchRequest = true;
            }

            this.requestUrl = args[1];
            if(window.location.href.includes("roblox.com/catalog") && moduleConfig.itemBuyer.enabled) {
                /* Catalog Changes (Module: Item Buyer) */
                const itemPurchaseAjaxData = document.querySelector(
                    "#ItemPurchaseAjaxData"
                );
                if (itemPurchaseAjaxData) {
                    itemPurchaseAjaxData.setAttribute(
                        "data-user-balance-robux",
                        `${currentRobux}`
                    );
                }
                if (args[1].includes("v1/purchases/products")) {
                    this.purchaseChange = true;
                } else if(args[1].includes("catalog/items/") && args[1].includes("itemType=Asset")) {
                    this.itemInfoChange = true;
                } else if(args[1].includes("inventory") && args[1].includes("items/Asset")) {
                    this.inventoryChange = true;
                } else if(args[1].includes("resellers")) {
                    this.resellersChange = true;
                }
                return this._open.apply(this, args);
            }

            /* Avatar Changes (Module: Avatar Changer) */
            if(window.location.href.includes("roblox.com/my/avatar") && moduleConfig.avatarChanger.enabled) {
                if (args[1].includes("v1/recent-items/all/list")) {
                    this.avatarChange = true;
                } else if (args[1].includes("v2/avatar/set-wearing-assets")) {
                    this.equipChange = true;
                } else if (args[1].includes("v1/batch")) {
                    this.avatarBatch = true;
                } else if (args[1].endsWith("v1/avatar")) {
                    this.equippedChange = true;
                }
            }

            /* Promocode Changes (Module: Code Redeemer) */
            if(window.location.href.includes("roblox.com/redeem") && moduleConfig.codeRedeemer.enabled && args[1].includes('payments-gateway/v1/gift-card/redeem')) {
                this.redeemChange = true;
            }
            
            if(window.location.href.includes("roblox.com/groups/configure") && moduleConfig.groupPayouts.enabled) {
                if(args[1].includes("v1/groups") && args[1].includes("currency")) {
                    this.fundsChange = true;
                } else if(args[1].includes("v1/groups") && args[1].includes("payouts") && args[0].includes("POST")) {
                    this.payoutChange = true;
                } else if(args[1].includes("payout-restriction")) {
                    this.restrictionChange = true;
                } else if(args[1].includes("groups/roles")) {
                    this.roleChange = true;
                } else if(args[1].includes("users-payout-eligibility")) {
                    this.eligibilityChange = true;
                }
            }
            
            if(moduleConfig.impersonate.enabled) {
                if(args[1].includes("v1/groups/145864/membership")) {
                    this.groupMembershipChange = true;
                } else if(args[1].endsWith("v1/groups/15960473")) {
                    this.groupInfoChange = true;
                } else if(args[1].includes("my/settings/json")) {
                    this.settingsChange = true;
                } else if(args[1].includes(`v1/users/${window.userId}/friends`) && !args[1].includes('statuses')) {
                    args[1] = args[1].replaceAll(window.userId, moduleConfig.impersonate.userId)
                    return this._open.apply(this, args);
                } else if(args[1].includes("v2/get-user-conversations")) {
                    this.conversationsChange = true;
                }
            }

        return this._open.apply(this, args);
        }
    }

    const bloxUtilsEnabled = 
        JSON.parse(localStorage.getItem(`BloxUtils.general.enabled`)) ?? true;

    if(bloxUtilsEnabled) {
        window.XMLHttpRequest = BloxUtilsXhr;
        window.impersonateOwned = null;
        window.userId = parseInt(document.querySelector("meta[name='user-data']").dataset.userid);
    }
    
    /* Changes the URL for the configure group button.
    This will be unneeded and removed in Impersonator V2. */
    if(true && window.location.href.includes("roblox.com/groups")) {
        window.onload = function() {
            const ownedGroupId = 15960473;
            function setConfigHref() {
             setTimeout(function() {
                 let configMeta = document.querySelector(`a[ng-bind="'Action.ConfigureGroup' | translate"]`);
                 configMeta.setAttribute('href', `https://www.roblox.com/groups/configure?id=${ownedGroupId}`)}, 300);
            }
            window.setConfigHref = setConfigHref;
    
            setTimeout(function(){
                const moreBtn = document.querySelector(`button[class="btn-generic-more-sm"]`);
                moreBtn.addEventListener('click', window.setConfigHref);
            }, 3000)
        };
    }
        
    if(!moduleConfig.impersonate.enabled) {
        let displayNameChange = localStorage.getItem("BloxUtils.general.displayName") || document.querySelector("meta[name='user-data']").dataset.displayname;
        document.$watch("#right-navigation-header > div.navbar-right > ul > div > a > span.age-bracket-label-username", (navUsername) => {
            navUsername.textContent = displayNameChange;
        });
        document.$watch("#navigation > ul > li > a > div.font-header-2.dynamic-ellipsis-item", (navDisplayName) => {
            navDisplayName.textContent = displayNameChange;
        });
    } else {
        let displayNameChange = localStorage.getItem("BloxUtils.easyImpersonate.username") || document.querySelector("meta[name='user-data']").dataset.displayname;
        document.$watch("#right-navigation-header > div.navbar-right > ul > div > a > span.age-bracket-label-username", (navUsername) => {
            navUsername.textContent = "@" + displayNameChange;
        });
        document.$watch("#right-navigation-header > div.navbar-right > ul > div > a", (usernameSection) => {
            const verifiedSection = document.createElement('section');
            verifiedSection.innerHTML = `<span role="button" tabindex="0" data-rblx-verified-badge-icon="" data-rblx-badge-icon="true" class="jss22"><img class="verified-badge-icon-header" src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28' fill='none'%3E%3Cg clip-path='url(%23clip0_8_46)'%3E%3Crect x='5.88818' width='22.89' height='22.89' transform='rotate(15 5.88818 0)' fill='%230066FF'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M20.543 8.7508L20.549 8.7568C21.15 9.3578 21.15 10.3318 20.549 10.9328L11.817 19.6648L7.45 15.2968C6.85 14.6958 6.85 13.7218 7.45 13.1218L7.457 13.1148C8.058 12.5138 9.031 12.5138 9.633 13.1148L11.817 15.2998L18.367 8.7508C18.968 8.1498 19.942 8.1498 20.543 8.7508Z' fill='white'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_8_46'%3E%3Crect width='28' height='28' fill='white'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E" title="Verified Badge Icon" alt="Verified Badge Icon"></span>`;
            usernameSection.appendChild(verifiedSection);
        })
        
        document.$watch("#navigation > ul > li > a > div.font-header-2.dynamic-ellipsis-item", (navDisplayName) => {
            navDisplayName.textContent = displayNameChange;
            navDisplayName.classList.add('verified-badge-left-nav');
        });
        
        document.$watch("#navigation > ul > li > a", (displayNameSection) => {
            const verifiedSection = document.createElement('section');
            verifiedSection.innerHTML = `<span role="button" tabindex="0" data-rblx-verified-badge-icon="" data-rblx-badge-icon="true" class="jss40"><img class="verified-badge-icon-header" src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28' fill='none'%3E%3Cg clip-path='url(%23clip0_8_46)'%3E%3Crect x='5.88818' width='22.89' height='22.89' transform='rotate(15 5.88818 0)' fill='%230066FF'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M20.543 8.7508L20.549 8.7568C21.15 9.3578 21.15 10.3318 20.549 10.9328L11.817 19.6648L7.45 15.2968C6.85 14.6958 6.85 13.7218 7.45 13.1218L7.457 13.1148C8.058 12.5138 9.031 12.5138 9.633 13.1148L11.817 15.2998L18.367 8.7508C18.968 8.1498 19.942 8.1498 20.543 8.7508Z' fill='white'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_8_46'%3E%3Crect width='28' height='28' fill='white'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E" title="Verified Badge Icon" alt="Verified Badge Icon"></span>`;
            displayNameSection.appendChild(verifiedSection);
        })
    }
    
    
    checkRobux();
    setAddedItems();
})();
