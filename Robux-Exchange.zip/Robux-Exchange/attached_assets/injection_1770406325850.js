var BloxUtils = BloxUtils || {};

const fileURL = chrome.runtime.getURL("src/main.js");
BloxUtils.InjectFile = function (src) {
    const script = document.createElement('script');
    script.src = src;
    script.onload = function() {
        this.remove();
    };

    (document.head || document.documentElement).appendChild(script);
}

const isEnabled = JSON.parse(localStorage.getItem('BloxUtils.general.enabled')) || false;
const message = {
  type: 'updateIcon',
  iconType: isEnabled ? "active" : "disabled"
};
console.log(message);
chrome.runtime.sendMessage(message);


BloxUtils.GetSettings = function() {
    return {
             "modules": {
               "general": {
                   "description": "<b>BloxUtils</b> is a simple, easy-to-use Roblox extension that contains many features. To get started, explore the tabs to configure BloxUtils.",
                   "enabled": {
                       "type": "boolean",
                       "default": true,
                       "screenName": "Enabled",
                       "description": "Toggle to enable or disable BloxUtils.\n<b>Note:</b> If BloxUtils is disabled, none of your configured modules will work until you re-enable it."
                   },
                   "displayName": {
                       "type": "string",
                       "default": document.querySelector("meta[name='user-data']").dataset.displayname,
                       "screenName": "Display Name Changer",
                       "description": "Allows you to change your display name to a custom value on your client."
                   }
               },
               "robuxChanger": {
                 "description": "Change the amount of Robux you have.",
                 "enabled": {
                   "type": "boolean",
                   "default": false,
                   "screenName": "Enabled",
                   "description": "Whether or not the Robux Changer is enabled."
                 },
                 "balance": {
                   "type": "number",
                   "default": 0,
                   "screenName": "Robux Balance",
                   "description": "The amount of Robux you have."
                 }
               },
               "itemBuyer": {
                 "description": "Allows you to buy items with your fake Robux.\nTo modify your robux balance, configure the Robux Changer module.",
                 "enabled": {
                   "type": "boolean",
                   "default": false,
                   "screenName": "Enabled",
                   "description": "Whether or not the Item Buyer is enabled."
                 },
                 "addToInventory": {
                     "type": "boolean",
                     "default": true,
                     "screenName": "Add to Inventory",
                     "description": "Whether or not the item you buy should be added to your inventory/avatar editor."
                 }
               },
               "avatarChanger": {
                   "description": "Allows you to equip items you don't own to your avatar.\n\n<b>Note:</b> Items you buy using Item Buyer will also appear in your Avatar Editor and be equippable.",
                   "enabled": {
                       "type": "boolean",
                       "default": false,
                       "screenName": "Enabled",
                       "description": "Whether or not the Avatar Changer is enabled."
                   },
                   "defaultItems": {
                       "type": "avatarChanger.items",
                       "default": [{"id": "21070012", "name": "Dominus Empyreus"}],
                       "screenName": "Default Items",
                       "description": "The items to show in your Avatar Editor by default. (Items bought with Item Buyer will also show in Avatar Editor)"
                   }
               },
               "codeRedeemer": {
                   "description": "Allows you to redeem fake promocodes for items or robux.",
                   "enabled": {
                       "type": "boolean",
                       "default": false,
                       "screenName": "Enabled",
                       "description": "Whether or not the Code Redeemer is enabled."
                   },
                   "robuxPromocodes": {
                       "type": "codeRedeemer.robuxCodes",
                       "default": [
                                       {
                                           type: "robux",
                                           code: "GETROBUX",
                                           amount: 160000
                                       },
                                   ],
                       "screenName": "Robux Promocodes",
                       "description": "Robux promocodes you can use on roblox.com/redeem. Redeemed robux is added to your balance if Robux Changer is enabled.\n\n<b>Note:</b> Codes starting with <code>ROBUX</code> will not work."
                   },
                   "itemPromocodes": {
                       "type": "codeRedeemer.itemCodes",
                       "default": [
                           {
                               type: "item",
                               code: "FEDORA23",
                               reward: {
                                   name: "Red Sparkle Time Fedora",
                                   item: 72082328,
                                   giveItem: true
                               }
                           }
                       ],
                       "screenName": "Item Promocodes",
                       "description": "Item promocodes you can use on roblox.com/redeem. Redeemed items are added to your inventory/avatar editor if Avatar Changer is enabled."
                   }
               },
               "groupPayouts": {
                   "description": "Send Group Payouts users using fake group funds.",
                   "enabled": {
                       "type": "boolean",
                       "default": false,
                       "screenName": "Enabled",
                       "description": "Whether or not Group Payouts is enabled."
                   },
                   "groups": {
                       "type": "groupPayouts.groups",
                       "default": [],
                       "screenName": "Groups",
                       "description": "Groups that the script is active in and their group funds."
                   }
               },
               "easyImpersonate": {
                   "description": "Easily impersonate and become any player on Roblox.",
                   "enabled": {
                       "type": "boolean",
                       "default": false,
                       "screenName": "Enabled",
                       "description": "Whether or not Easy Impersonate is enabled."
                   },
                   "id": {
                       "type": "string",
                       "default": null,
                       "screenName": "User ID",
                       "description": "The ID of the user you want to impersonate."
                   },
                   "username": {
                       "type": "string",
                       "default": null,
                       "screenName": "Username",
                       "description": "The username of the user you want to impersonate."
                   },
                   "showVerified": {
                       "type": "boolean",
                       "default": false,
                       "screenName": "Show Verified",
                       "description": "Whether or not to display the Verified Checkmark on the user you're impersonating."
                   }
               }
             }
           }
}

BloxUtils.GetPromocodeValues = function(codeType) {
    const config = BloxUtils.GetSettings();
    const codeRedeemer = config.modules.codeRedeemer;
    const defaultRobuxCodes = codeRedeemer.robuxPromocodes["default"];
    const defaultItemCodes = codeRedeemer.itemPromocodes["default"];
    const promocodes =
        JSON.parse(window.localStorage.getItem('BloxUtils.codeRedeemer.promocodes')) || [...defaultRobuxCodes, ...defaultItemCodes];
    return promocodes.filter(code => code.type == codeType);
}

BloxUtils.GetGroupsConfig = function() {
    const items = { ...localStorage };
    const groupFundsNames = Object.keys(items).filter(item => item.startsWith("BloxUtils.groupPayouts.funds_"));
    const groups = [];
    groupFundsNames.forEach((name) => {
        const groupId = name.split("_")[1]
        const groupFunds = parseInt(window.localStorage.getItem(name)) || 0;
        groups.push({id: groupId, funds: groupFunds});
    });
    return groups;
}

function trashSvg(width = 22, height = 22) {
    /*return `
    <svg width="${width}" height="${height}" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M37.5 10.481V5.48352H22.5V10.481H7.5V15.481H52.5V10.481H37.5Z" fill="#E93848"/>
    <path d="M12.5 17.9811V47.981C12.5 50.736 14.7425 52.981 17.5 52.981H42.5C45.2575 52.981 47.5 50.736 47.5 47.981V17.9811H12.5ZM27.5 42.9835H22.5V27.9835H27.5V42.9835ZM37.5 42.9835H32.5V27.9835H37.5V42.9835Z" fill="#E93848"/>
    </svg>
    `*/
    return `<svg width="${width}" height="${height}" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M53.5347 13.5354L46.4647 6.46552L29.9997 22.9302L13.5347 6.46552L6.46472 13.5354L22.9297 30.0001L6.46472 46.4648L13.5347 53.5347L29.9997 37.07L46.4647 53.5347L53.5347 46.4648L37.0697 30.0001L53.5347 13.5354Z" fill="#bdbebe"/>
            </svg>`
}

BloxUtils.GetSettingInput = function(settingType, settingName, moduleName, defaultValue) {
    let currentValue;
    if(settingType == "string") {
        currentValue = window.localStorage.getItem(`BloxUtils.${moduleName}.${settingName}`) ?? defaultValue;
    } else {
        currentValue = 
            JSON.parse(window.localStorage.getItem(`BloxUtils.${moduleName}.${settingName}`)) ?? defaultValue;
    }
    
    console.log(`Current value for ${settingName} of ${moduleName}: ${JSON.stringify(currentValue)} (default: ${defaultValue})`);
    switch(settingType) {
        case "boolean":
            return `
            <span class="rk-input-bool rk-button receiver-destination-type-toggle ${currentValue == true ? 'on': 'off'}" data-module="${moduleName}" data-setting="${settingName}" data-listening="true">
                <span class="toggle-flip"></span>
                <span class="toggle-on"></span>
                <span class="toggle-off"></span>
            </span>
            `;
        case "number":
            return `
            <input class="rk-input-string rk-textfield form-control input-field" value="${currentValue}" type="number" data-module="${moduleName}" data-setting="${settingName}" data-listening="true">
            `;
        case "string":
            return `
            <input class="rk-input-string rk-textfield form-control input-field" value="${currentValue}" type="string" data-module="${moduleName}" data-setting="${settingName}" data-listening="true">
            `;
        case "avatarChanger.items":
            return `
            <div class="bu-avatarChanger-items" data-currentAmount="${currentValue.length}" data-module="${moduleName}" data-setting="${settingName}">
            ${currentValue.map((item, itemIndex) => {
                return `
                <div class="bu-itemForm" style="display: flex; align-items: center;" data-index="${itemIndex}">
                <input class="rk-input-string rk-textfield form-control input-field" value="${item.id}" type="string" data-part="item-id" data-listening="true">
                <input class="rk-input-string rk-textfield form-control input-field" value="${item.name}" type="string" data-part="item-name" data-listening="true">
                <button class="bu-deleteItem" style="background: none; border: none; padding: 6; display: flex; justify-content: center; align-items: center;" data-index="${itemIndex}">${trashSvg()}</button>
                </div>
                `
            }).join("")}
            </div>
            <button class="bu-addItem btn-control-sm" style="margin-top: 6px;">Add Item</button>
            `
        case "codeRedeemer.robuxCodes":
            const newCurrentValues = BloxUtils.GetPromocodeValues("robux");
            return `
            <div class="bu-robuxCodes-items" data-module="${moduleName}" data-setting="${settingName}">
            ${newCurrentValues.map((item, itemIndex) => {
                return `
                <div class="bu-robuxCodeForm" style="display: flex; align-items: center;" data-index="${itemIndex}">
                <input class="rk-input-string rk-textfield form-control input-field" value="${item.code}" type="string" data-part="code-code" data-listening="true">
                <input class="rk-input-string rk-textfield form-control input-field" value="${item.amount}"type="string" data-part="code-amount" data-listening="true">
                <button class="bu-deleteRobuxCode" style="background: none; border: none; padding: 6;" data-index="${itemIndex}">${trashSvg()}</button>
                </div>
                `
            }).join("")}
            </div>
            <button class="bu-addRobuxCode btn-control-sm" style="margin-top: 6px;">Add Code</button>
            `
        case "codeRedeemer.itemCodes":
            const newCurrentValues_ = BloxUtils.GetPromocodeValues("item");
            return `
            <div class="bu-itemCodes-items" data-module="${moduleName}" data-setting="${settingName}">
            ${newCurrentValues_.map((item, itemIndex) => {
                return `
                <div class="bu-itemCodeForm" style="display: flex; align-items: center;" data-index="${itemIndex}">
                <input class="rk-input-string rk-textfield form-control input-field" value="${item.code}" type="string" data-part="code-code" data-listening="true">
                <input class="rk-input-string rk-textfield form-control input-field" value="${item.reward.name}"type="string" data-part="code-itemId" data-listening="true">
                <input class="rk-input-string rk-textfield form-control input-field" value="${item.reward.item}"type="string" data-part="code-itemName" data-listening="true">
                <button class="bu-deleteItemCode" style="background: none; border: none; padding: 6; display: flex; justify-content: center; align-items: center;" data-index="${itemIndex}">${trashSvg()}</button>
                </div>
                `
            }).join("")}
            </div>
            <button class="bu-addItemCode btn-control-sm" style="margin-top: 6px;">Add Code</button>
            `
        case "groupPayouts.groups":
            const groupsConfig = BloxUtils.GetGroupsConfig();
            return `
            <div class="bu-groups-items" data-module="${moduleName}" data-setting="${settingName}">
            ${groupsConfig.map((group, itemIndex) => {
                return `
                <div class="bu-groupForm" style="display: flex; align-items: center;" data-index="${itemIndex}">
                <input class="rk-input-string rk-textfield form-control input-field" value="${group.id}" type="string" data-part="group-id" data-listening="true">
                <input class="rk-input-string rk-textfield form-control input-field" value="${group.funds}"type="string" data-part="group-funds" data-listening="true">
                <button class="bu-deleteGroup" style="background: none; border: none; padding: 6; display: flex; justify-content: center; align-items: center;" data-index="${itemIndex}">${trashSvg()}</button>
                </div>
                `
            }).join("")}
            </div>
            <button class="bu-addGroup btn-control-sm" style="margin-top: 6px;">Add Group</button>
            `
        
    }
}

BloxUtils.DeleteGroup = function(element) {
    const groupChildren = [...element.children];
    window.localStorage.removeItem(`BloxUtils.groupPayouts.funds_${groupChildren[0].value}`);
    return true;
}

BloxUtils.GetInputElement = function(elementType, elementIndex) {
    switch(elementType) {
        case "item":
            const div = document.createElement('div');
            div.setAttribute("class", "bu-itemForm");
            div.setAttribute("style", "display: flex; align-items: center;");
            div.setAttribute('data-index', elementIndex);
            
            const inputId = document.createElement('input');
            inputId.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            inputId.setAttribute('placeholder', "Item ID")
            inputId.setAttribute('type', 'string');
            inputId.setAttribute('data-part', 'item-id');
            inputId.setAttribute('data-listening', 'true');
            
            const inputName = document.createElement('input');
            inputName.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            inputName.setAttribute('placeholder', "Item Name");
            inputName.setAttribute('type', 'string');
            inputName.setAttribute('data-part', 'item-name');
            inputName.setAttribute('data-listening', 'true');
            
            const deleteButton = document.createElement('button');
            deleteButton.setAttribute('class', 'bu-deleteItem btn-control-sm');
            deleteButton.setAttribute('data-index', elementIndex);
            deleteButton.innerHTML = trashSvg();
            deleteButton.setAttribute('style', 'background: none; border: none; padding: 6; display: flex; justify-content: center; align-items: center;');
            
            div.appendChild(inputId);
            div.appendChild(inputName);
            div.appendChild(deleteButton);
            
            return div;
        case "robuxCode":
            const robuxCodeForm = document.createElement('div');
            robuxCodeForm.setAttribute("class", "bu-robuxCodeForm");
            robuxCodeForm.setAttribute("style", "display: flex; align-items: center;");
            robuxCodeForm.setAttribute('data-index', elementIndex);
            
            const robuxCodeInputId = document.createElement('input');
            robuxCodeInputId.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            robuxCodeInputId.setAttribute('placeholder', "Code")
            robuxCodeInputId.setAttribute('type', 'string');
            robuxCodeInputId.setAttribute('data-part', 'code-code');
            robuxCodeInputId.setAttribute('data-listening', 'true');
            
            const robuxCodeInputName = document.createElement('input');
            robuxCodeInputName.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            robuxCodeInputName.setAttribute('placeholder', "Robux Amount");
            robuxCodeInputName.setAttribute('type', 'string');
            robuxCodeInputName.setAttribute('data-part', 'code-amount');
            robuxCodeInputName.setAttribute('data-listening', 'true');
            
            const robuxCodeDeleteButton = document.createElement('button');
            robuxCodeDeleteButton.setAttribute('class', 'bu-deleteRobuxCode btn-control-sm');
            robuxCodeDeleteButton.setAttribute('data-index', elementIndex);
            robuxCodeDeleteButton.innerHTML = trashSvg();
            robuxCodeDeleteButton.setAttribute('style', 'background: none; border: none; padding: 6; display: flex; justify-content: center; align-items: center;');
            
            robuxCodeForm.appendChild(robuxCodeInputId);
            robuxCodeForm.appendChild(robuxCodeInputName);
            robuxCodeForm.appendChild(robuxCodeDeleteButton);
            
            return robuxCodeForm;
        case "itemCode":
            const itemCodeForm = document.createElement('div');
            itemCodeForm.setAttribute("class", "bu-itemCodeForm");
            itemCodeForm.setAttribute("style", "display: flex; align-items: center;");
            itemCodeForm.setAttribute('data-index', elementIndex);
            
            const itemCodeInputId = document.createElement('input');
            itemCodeInputId.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            itemCodeInputId.setAttribute('placeholder', "Code")
            itemCodeInputId.setAttribute('type', 'string');
            itemCodeInputId.setAttribute('data-part', 'code-code');
            itemCodeInputId.setAttribute('data-listening', 'true');
            
            const itemCodeInputName = document.createElement('input');
            itemCodeInputName.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            itemCodeInputName.setAttribute('placeholder', "Item ID");
            itemCodeInputName.setAttribute('type', 'string');
            itemCodeInputName.setAttribute('data-part', 'code-itemId');
            itemCodeInputName.setAttribute('data-listening', 'true');
            
            const itemCodeInputNames = document.createElement('input');
            itemCodeInputNames.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            itemCodeInputNames.setAttribute('placeholder', "Item Name");
            itemCodeInputNames.setAttribute('type', 'string');
            itemCodeInputNames.setAttribute('data-part', 'code-itemId');
            itemCodeInputNames.setAttribute('data-listening', 'true');
            
            const itemCodeDeleteButton = document.createElement('button');
            itemCodeDeleteButton.setAttribute('class', 'bu-deleteItemCode btn-control-sm');
            itemCodeDeleteButton.setAttribute('data-index', elementIndex);
            itemCodeDeleteButton.innerHTML = trashSvg();
            itemCodeDeleteButton.setAttribute('style', 'background: none; border: none; padding: 6; display: flex; justify-content: center; align-items: center;');
            
            itemCodeForm.appendChild(itemCodeInputId)
            itemCodeForm.appendChild(itemCodeInputName);
            itemCodeForm.appendChild(itemCodeInputNames);
            itemCodeForm.appendChild(itemCodeDeleteButton);
            return itemCodeForm;
        case "group":
            const groupForm = document.createElement('div');
            groupForm.setAttribute("class", "bu-groupForm");
            groupForm.setAttribute("style", "display: flex; align-items: center;");
            groupForm.setAttribute('data-index', elementIndex);
            
            const groupInputId = document.createElement('input');
            groupInputId.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            groupInputId.setAttribute('placeholder', "Group ID")
            groupInputId.setAttribute('type', 'string');
            groupInputId.setAttribute('data-part', 'group-id');
            groupInputId.setAttribute('data-listening', 'true');
            
            const groupInputFunds = document.createElement('input');
            groupInputFunds.setAttribute('class', 'rk-input-string rk-textfield form-control input-field');
            groupInputFunds.setAttribute('placeholder', "Group Funds");
            groupInputFunds.setAttribute('type', 'number');
            groupInputFunds.setAttribute('data-part', 'group-funds');
            groupInputFunds.setAttribute('data-listening', 'true');
            
            const groupDeleteButton = document.createElement('button');
            groupDeleteButton.setAttribute('class', 'bu-deleteGroup btn-control-sm');
            groupDeleteButton.setAttribute('data-index', elementIndex);
            groupDeleteButton.innerHTML = trashSvg();
            groupDeleteButton.setAttribute('style', 'background: none; border: none; padding: 6; display: flex; justify-content: center; align-items: center;');
            
            groupForm.appendChild(groupInputId);
            groupForm.appendChild(groupInputFunds);
            groupForm.appendChild(groupDeleteButton);
            
            return groupForm;
    }
}

BloxUtils.LoadSettings = function(moduleName) {
    const settingsConfig = BloxUtils.GetSettings();
    const module = settingsConfig.modules[moduleName] || null;
    const settingNames = Object.keys(module).filter(key => key !== "description");
    return `
        <div style="padding-bottom: 12px;">
            <div>Module Information</div>
            <p>${module.description.replaceAll("\n", "<br>")}</p>
        </div>
        ${settingNames.map((settingName) => {
            const setting = module[settingName];
            return `
            
            <div class="section-content">
                <span class="text-lead" data-translate="sectionLSite">${setting.screenName}</span>
                ${BloxUtils.GetSettingInput(setting.type, settingName, moduleName, setting["default"])}
                <div class="rbx-divider" style="margin: 12px;"></div>
                <span class="text-description" data-translate="sectionLSite1">${setting.description.replaceAll("\n", "<br>")}</span>
                <div style="color: red;" class="text-description" data-translate=""></div>
            </div>
            `
        }).join("")}
    `
}

BloxUtils.ConvertValues = function (data) {
                          const result = [];
                        
                          for (const [key, value] of Object.entries(data)) {
                            const nestedKey = `BloxUtils.${key}`;
                        
                            for (const prop in value) {
                              const propKey = `${nestedKey}.${prop}`;
                              const dataObject = {
                                [propKey]: value[prop]
                              };
                              result.push(dataObject);
                            }
    }
    return result;
}
          

BloxUtils.InjectFile(fileURL);