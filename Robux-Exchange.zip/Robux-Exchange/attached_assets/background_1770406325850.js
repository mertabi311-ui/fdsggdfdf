const updateIcon = function (tabId, iconType) {
  let iconName = iconType == "active" ? "48" : "48_disabled";

  chrome.action.setIcon({ path: {"48": '/images/' + iconName + '.png'} });
};

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message && message.type === 'updateIcon') {
      /* Currently disabled. */
    // updateIcon(sender.tab.id, message.iconType);
  }
});
