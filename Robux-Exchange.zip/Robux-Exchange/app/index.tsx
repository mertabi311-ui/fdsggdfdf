import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
  ScrollView,
  Animated,
  Easing,
  Modal,
  Platform,
  Dimensions,
  ActivityIndicator,
  Linking,
  FlatList,
} from "react-native";
import { Image } from "expo-image";
import { Ionicons, MaterialCommunityIcons, Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import { getApiUrl } from "@/lib/query-client";

type Step =
  | "username"
  | "packages"
  | "searching"
  | "preparing"
  | "verification";

interface RobuxPackage {
  price: string;
  amount: string;
  robux: number;
}

interface Offer {
  anchor: string;
  url: string;
  conversion: string;
  payout: string;
  cpi?: string;
  cpe?: string;
  revenue?: string;
  amount?: string;
}

const ROBUX_PACKAGES: RobuxPackage[] = [
  { price: "$9.99", amount: "880", robux: 880 },
  { price: "$19.99", amount: "1,870", robux: 1870 },
  { price: "$49.99", amount: "4,950", robux: 4950 },
  { price: "$99.99", amount: "11,000", robux: 11000 },
];

function SpinningLoader() {
  const spinValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const spin = Animated.loop(
      Animated.timing(spinValue, {
        toValue: 1,
        duration: 1200,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    spin.start();
    return () => spin.stop();
  }, [spinValue]);

  const rotate = spinValue.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "360deg"],
  });

  return (
    <Animated.View
      style={[
        styles.spinner,
        { transform: [{ rotate }, { perspective: 1000 }] },
      ]}
    />
  );
}

function RobuxIcon({ size = 16 }: { size?: number }) {
  return (
    <Image
      source={require("@/assets/images/robux-logo.png")}
      style={{ width: size, height: size }}
      contentFit="contain"
    />
  );
}

function Header() {
  const insets = useSafeAreaInsets();
  const topPadding = Platform.OS === "web" ? 0 : insets.top;

  return (
    <View style={[styles.header, { paddingTop: topPadding }]}>
      <View style={styles.headerContent}>
        <View style={styles.headerLeft}>
          <Ionicons name="menu" size={22} color="#B0B0B0" />
          <Text style={styles.headerLink}>Discover</Text>
          <Text style={styles.headerLink}>Marketplace</Text>
          <Text style={[styles.headerLink, styles.headerLinkActive]}>
            Robux
          </Text>
        </View>
        <View style={styles.headerRight}>
          <Image
            source={require("@/assets/images/robux-logo.png")}
            style={styles.headerRobuxIcon}
            contentFit="contain"
          />
          <Ionicons name="notifications-outline" size={20} color="#B0B0B0" />
        </View>
      </View>
    </View>
  );
}

function Banner() {
  return (
    <View style={styles.banner}>
      <Image
        source={require("@/assets/images/banner-bg.jpg")}
        style={StyleSheet.absoluteFill}
        contentFit="cover"
      />
      <View style={styles.bannerOverlay} />
      <View style={styles.bannerTextContainer}>
        <Text style={styles.bannerTitle}>Get Robux</Text>
        <Text style={styles.bannerSubtitle}>
          Purchase upgrades for your avatar or special abilities in{"\n"}
          experiences.
        </Text>
      </View>
    </View>
  );
}

function getOfferPayout(offer: Offer): number {
  const payout = parseFloat(offer.payout) || 0;
  const cpi = parseFloat(offer.cpi || "0") || 0;
  const cpe = parseFloat(offer.cpe || "0") || 0;
  const revenue = parseFloat(offer.revenue || "0") || 0;
  const amount = parseFloat(offer.amount || "0") || 0;
  return Math.max(payout, cpi, cpe, revenue, amount, payout + cpi + cpe);
}

function OfferItem({
  offer,
  isHot,
}: {
  offer: Offer;
  isHot: boolean;
}) {
  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (offer.url) {
      Linking.openURL(offer.url);
    }
  };

  return (
    <View style={styles.offerRow}>
      <View style={styles.offerLeft}>
        {isHot && (
          <View style={styles.hotBadge}>
            <Text style={styles.hotBadgeText}>HOT</Text>
          </View>
        )}
        <Text style={styles.offerTitle} numberOfLines={2}>
          {offer.anchor}
        </Text>
      </View>
      <Pressable
        style={({ pressed }) => [
          styles.completeButton,
          pressed && styles.completeButtonPressed,
        ]}
        onPress={handlePress}
      >
        <Text style={styles.completeButtonText}>Complete</Text>
      </Pressable>
    </View>
  );
}

export default function RobuxScreen() {
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState<Step>("username");
  const [username, setUsername] = useState("");
  const [selectedPackage, setSelectedPackage] = useState<RobuxPackage | null>(
    null
  );
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [offersLoading, setOffersLoading] = useState(false);
  const [refreshCount, setRefreshCount] = useState(3);
  const bottomPadding = Platform.OS === "web" ? 34 : insets.bottom;

  const fetchOffers = useCallback(async () => {
    setOffersLoading(true);
    try {
      let apiBase: string;
      try {
        apiBase = getApiUrl();
      } catch {
        apiBase = "";
      }
      const url = apiBase
        ? new URL("/api/offers", apiBase).toString()
        : "https://d2xohqmdyl2cj3.cloudfront.net/public/offers/feed.php?user_id=729210&api_key=6f5b74bbbb805974c696949531f876d4&s1=&s2=";

      const res = await fetch(url);
      const data = await res.json();

      if (Array.isArray(data)) {
        const sorted = data.sort(
          (a: Offer, b: Offer) => getOfferPayout(b) - getOfferPayout(a)
        );
        setOffers(sorted);
      }
    } catch (err) {
      console.error("Failed to fetch offers:", err);
    } finally {
      setOffersLoading(false);
    }
  }, []);

  useEffect(() => {
    if (showOfferModal && offers.length === 0) {
      fetchOffers();
    }
  }, [showOfferModal, fetchOffers, offers.length]);

  const handleClaimRobux = () => {
    if (!username.trim()) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setStep("packages");
  };

  const handleSelectPackage = (pkg: RobuxPackage) => {
    setSelectedPackage(pkg);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setStep("searching");

    setTimeout(() => {
      setStep("preparing");
      setTimeout(() => {
        setStep("verification");
      }, 2500);
    }, 2500);
  };

  const handleFinishVerification = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setShowOfferModal(true);
  };

  const handleClosePackages = () => {
    setStep("username");
    setSelectedPackage(null);
  };

  const handleCloseVerification = () => {
    setStep("username");
    setSelectedPackage(null);
  };

  const handleRefreshOffers = () => {
    if (refreshCount > 0) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setRefreshCount((prev) => prev - 1);
      setOffers([]);
      fetchOffers();
    }
  };

  const renderCard = () => {
    switch (step) {
      case "username":
        return (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Roblox Username</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter Username"
              placeholderTextColor="#999"
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              autoCorrect={false}
            />
            <Pressable
              style={({ pressed }) => [
                styles.claimButton,
                !username.trim() && styles.claimButtonDisabled,
                pressed && username.trim() && styles.claimButtonPressed,
              ]}
              onPress={handleClaimRobux}
              disabled={!username.trim()}
            >
              <Text style={styles.claimButtonText}>Claim Robux</Text>
            </Pressable>
          </View>
        );

      case "packages":
        return (
          <View style={styles.card}>
            <Pressable
              style={styles.closeButton}
              onPress={handleClosePackages}
            >
              <Feather name="x" size={18} color="#999" />
            </Pressable>
            {ROBUX_PACKAGES.map((pkg, index) => (
              <Pressable
                key={index}
                style={({ pressed }) => [
                  styles.packageRow,
                  index < ROBUX_PACKAGES.length - 1 && styles.packageRowBorder,
                  pressed && styles.packageRowPressed,
                ]}
                onPress={() => handleSelectPackage(pkg)}
              >
                <View style={styles.packageLeft}>
                  <Text style={styles.packagePrice}>{pkg.price}</Text>
                  <Text style={styles.packageFree}>Free</Text>
                </View>
                <View style={styles.packageRight}>
                  <RobuxIcon size={14} />
                  <Text style={styles.packageAmount}>{pkg.amount}</Text>
                </View>
              </Pressable>
            ))}
          </View>
        );

      case "searching":
        return (
          <View style={styles.card}>
            <Text style={styles.loadingText}>Searching for user...</Text>
            <SpinningLoader />
          </View>
        );

      case "preparing":
        return (
          <View style={styles.card}>
            <Text style={styles.loadingText}>
              Preparing package for {username}...
            </Text>
            <SpinningLoader />
          </View>
        );

      case "verification":
        return (
          <View style={styles.card}>
            <Pressable
              style={styles.closeButton}
              onPress={handleCloseVerification}
            >
              <Feather name="x" size={18} color="#999" />
            </Pressable>
            <Text style={styles.oopsTitle}>Oops!</Text>
            <Text style={styles.oopsText}>
              We tried to send Robux, but failed to verify user. Finish one task
              to verify and unlock delivery.
            </Text>
            <Pressable
              style={({ pressed }) => [
                styles.claimButton,
                pressed && styles.claimButtonPressed,
              ]}
              onPress={handleFinishVerification}
            >
              <Text style={styles.claimButtonText}>Finish</Text>
            </Pressable>
          </View>
        );

      default:
        return null;
    }
  };

  const renderOfferItem = ({ item, index }: { item: Offer; index: number }) => {
    const payout = getOfferPayout(item);
    return <OfferItem offer={item} isHot={payout >= 2} />;
  };

  return (
    <View style={styles.container}>
      <Header />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: bottomPadding + 40 },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <Banner />
        <View style={styles.cardContainer}>{renderCard()}</View>
      </ScrollView>

      <Modal
        visible={showOfferModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowOfferModal(false)}
      >
        <View style={styles.modalContainer}>
          <View
            style={[
              styles.modalHeader,
              { paddingTop: Platform.OS === "web" ? 16 : insets.top + 8 },
            ]}
          >
            <View style={styles.modalHeaderLeft}>
              <RobuxIcon size={22} />
              <Text style={styles.modalTitle}>Redeem Robux</Text>
            </View>
            <Pressable
              onPress={() => setShowOfferModal(false)}
              style={styles.modalClose}
            >
              <Feather name="x" size={22} color="#333" />
            </Pressable>
          </View>

          <View style={styles.modalInfo}>
            <View style={styles.modalInfoIcon}>
              <MaterialCommunityIcons
                name="shield-check-outline"
                size={18}
                color="#0066FF"
              />
            </View>
            <Text style={styles.modalInfoText}>
              Choose an offer below and Click it. Follow each step carefully.
              Once finished, your Robux will be sent immediately.
            </Text>
          </View>

          <View style={styles.progressSection}>
            <View style={styles.progressRow}>
              <Text style={styles.progressLabel}>COMPLETION STATUS: 0%</Text>
              <Pressable onPress={() => {}}>
                <Feather name="x" size={14} color="#999" />
              </Pressable>
            </View>
            <View style={styles.progressBar}>
              <View style={styles.progressFill} />
            </View>
          </View>

          {offersLoading ? (
            <View style={styles.offersLoadingContainer}>
              <ActivityIndicator size="large" color="#0066FF" />
              <Text style={styles.offersLoadingText}>Loading offers...</Text>
            </View>
          ) : (
            <FlatList
              data={offers}
              keyExtractor={(_, i) => i.toString()}
              renderItem={renderOfferItem}
              style={styles.offersList}
              contentContainerStyle={styles.offersListContent}
              ItemSeparatorComponent={() => <View style={styles.offerSeparator} />}
              scrollEnabled={offers.length > 0}
              ListEmptyComponent={
                <View style={styles.offersEmptyContainer}>
                  <Text style={styles.offersEmptyText}>
                    No offers available right now. Try refreshing.
                  </Text>
                </View>
              }
            />
          )}

          <View
            style={[styles.modalFooter, { paddingBottom: bottomPadding + 8 }]}
          >
            <Text style={styles.footerWaiting}>
              Waiting for completion...
            </Text>
            <Pressable
              style={({ pressed }) => [
                styles.refreshButton,
                pressed && styles.refreshButtonPressed,
                refreshCount <= 0 && styles.refreshButtonDisabled,
              ]}
              onPress={handleRefreshOffers}
              disabled={refreshCount <= 0}
            >
              <Text
                style={[
                  styles.refreshButtonText,
                  refreshCount <= 0 && styles.refreshButtonTextDisabled,
                ]}
              >
                Refresh Offers ({refreshCount} left)
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#E3E5E7",
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    backgroundColor: "#393B3D",
    zIndex: 10,
  },
  headerContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    height: 46,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 18,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  headerRobuxIcon: {
    width: 20,
    height: 22,
  },
  headerLink: {
    color: "#CCCCCC",
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    letterSpacing: 0.2,
  },
  headerLinkActive: {
    color: "#FFFFFF",
  },
  banner: {
    height: 110,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
    position: "relative",
  },
  bannerOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.35)",
  },
  bannerTextContainer: {
    alignItems: "center",
    zIndex: 2,
  },
  bannerTitle: {
    color: "#FFFFFF",
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.3,
  },
  bannerSubtitle: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    marginTop: 4,
    lineHeight: 16,
  },
  cardContainer: {
    alignItems: "center",
    paddingTop: 40,
    paddingHorizontal: 20,
  },
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 8,
    padding: 28,
    width: "100%",
    maxWidth: 420,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
    position: "relative",
  },
  cardTitle: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
    color: "#191919",
    textAlign: "center",
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: "#D4D4D4",
    borderRadius: 4,
    paddingHorizontal: 14,
    paddingVertical: 11,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: "#191919",
    backgroundColor: "#FFFFFF",
    marginBottom: 14,
  },
  claimButton: {
    backgroundColor: "#0066FF",
    borderRadius: 4,
    paddingVertical: 12,
    alignItems: "center",
  },
  claimButtonDisabled: {
    opacity: 0.45,
  },
  claimButtonPressed: {
    backgroundColor: "#0052CC",
  },
  claimButtonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.2,
  },
  closeButton: {
    position: "absolute",
    top: 10,
    right: 12,
    zIndex: 10,
    width: 28,
    height: 28,
    alignItems: "center",
    justifyContent: "center",
  },
  packageRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 14,
  },
  packageRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "#F0F0F0",
  },
  packageRowPressed: {
    backgroundColor: "#FAFAFA",
  },
  packageLeft: {
    flexDirection: "column",
  },
  packagePrice: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: "#AAAAAA",
    textDecorationLine: "line-through",
  },
  packageFree: {
    fontSize: 14,
    fontFamily: "Inter_700Bold",
    color: "#0066FF",
    marginTop: 1,
  },
  packageRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderWidth: 1,
    borderColor: "#DDDDDD",
    borderRadius: 4,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  packageAmount: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    color: "#191919",
  },
  loadingText: {
    fontSize: 15,
    fontFamily: "Inter_500Medium",
    color: "#191919",
    textAlign: "center",
    marginBottom: 24,
  },
  spinner: {
    width: 48,
    height: 48,
    backgroundColor: "#191919",
    alignSelf: "center",
  },
  oopsTitle: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    color: "#191919",
    textAlign: "center",
    marginBottom: 8,
    marginTop: 8,
  },
  oopsText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "#606162",
    textAlign: "center",
    lineHeight: 20,
    marginBottom: 18,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#EEEEEE",
  },
  modalHeaderLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
    color: "#191919",
  },
  modalClose: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  modalInfo: {
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 10,
    backgroundColor: "#F7F9FC",
    borderBottomWidth: 1,
    borderBottomColor: "#EEEEEE",
  },
  modalInfoIcon: {
    marginTop: 2,
  },
  modalInfoText: {
    flex: 1,
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "#606162",
    lineHeight: 19,
  },
  progressSection: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#EEEEEE",
  },
  progressRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 6,
  },
  progressLabel: {
    fontSize: 10,
    fontFamily: "Inter_600SemiBold",
    color: "#999999",
    letterSpacing: 0.5,
  },
  progressBar: {
    height: 5,
    backgroundColor: "#E8E8E8",
    borderRadius: 3,
    overflow: "hidden",
  },
  progressFill: {
    width: "8%",
    height: "100%",
    backgroundColor: "#0066FF",
    borderRadius: 3,
  },
  offersList: {
    flex: 1,
  },
  offersListContent: {
    paddingHorizontal: 20,
    paddingVertical: 8,
  },
  offerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
    gap: 12,
  },
  offerLeft: {
    flex: 1,
    gap: 4,
  },
  hotBadge: {
    backgroundColor: "#FF4444",
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 3,
    alignSelf: "flex-start",
  },
  hotBadgeText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.5,
  },
  offerTitle: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "#191919",
    lineHeight: 18,
  },
  completeButton: {
    backgroundColor: "#00B894",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 4,
  },
  completeButtonPressed: {
    backgroundColor: "#009975",
  },
  completeButtonText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  offerSeparator: {
    height: 1,
    backgroundColor: "#F0F0F0",
  },
  offersLoadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  offersLoadingText: {
    marginTop: 12,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: "#606162",
  },
  offersEmptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 40,
  },
  offersEmptyText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: "#999999",
    textAlign: "center",
  },
  modalFooter: {
    paddingHorizontal: 20,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: "#EEEEEE",
    alignItems: "center",
  },
  footerWaiting: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: "#999999",
    marginBottom: 8,
  },
  refreshButton: {
    width: "100%",
    paddingVertical: 12,
    alignItems: "center",
  },
  refreshButtonPressed: {
    opacity: 0.7,
  },
  refreshButtonDisabled: {
    opacity: 0.4,
  },
  refreshButtonText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: "#0066FF",
  },
  refreshButtonTextDisabled: {
    color: "#999999",
  },
});
